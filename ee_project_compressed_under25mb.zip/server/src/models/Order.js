import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  orderId: { type: String, required: true },
  artId: { type: mongoose.Schema.Types.ObjectId, ref: 'Artwork', required: true },
  buyerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true },
  date: { type: Date, default: Date.now },
  status: { type: String, default: 'Paid' }
}, { timestamps: true });

const Order = mongoose.model('Order', orderSchema);
export default Order;
