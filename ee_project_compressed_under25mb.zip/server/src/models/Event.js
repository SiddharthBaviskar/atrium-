import mongoose from 'mongoose';

const eventSchema = new mongoose.Schema({
  title: { type: String, required: true },
  type: { type: String, enum: ['workshop', 'exhibition', 'online', 'sale'], required: true },
  artistId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  date: { type: String, required: true },
  loc: { type: String, required: true },
  fee: { type: Number, default: 0 },
  seats: { type: Number, default: 0 },
  description: { type: String, required: true },
  status: { type: String, enum: ['active', 'cancelled', 'completed'], default: 'active' },
  regs: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    userName: String,
    ticketId: String,
    seat: String,
    at: { type: Date, default: Date.now }
  }]
}, { timestamps: true });

const Event = mongoose.model('Event', eventSchema);
export default Event;
