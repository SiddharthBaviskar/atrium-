import mongoose from 'mongoose';

const postSchema = new mongoose.Schema({
  artistId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  text: { type: String, required: true },
  tag: { type: String },
  likes: { type: Number, default: 0 },
  shares: { type: Number, default: 0 },
  imageUrl: { type: String }
}, { timestamps: true });

const Post = mongoose.model('Post', postSchema);
export default Post;
