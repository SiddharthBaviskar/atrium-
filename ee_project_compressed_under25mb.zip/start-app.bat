@echo off
echo =========================================
echo    STARTING ATRIUM (FRONTEND + BACKEND)
echo =========================================
echo.

:: Start Backend
echo [1/2] Starting Backend Server...
start cmd /k "cd /d c:\coding\atrium-verse\atrium 2.1\server && npm install && npm run dev"

:: Start Frontend
echo [2/2] Starting Frontend Client...
start cmd /k "cd /d c:\coding\atrium-verse\atrium 2.1\client && npm install && npm run dev"

echo.
echo Both servers are starting in separate windows.
echo Please check the windows for status.
echo.
pause
