import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';

const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

interface ArtistsPageProps {
  onAuthOpen: (mode: 'login' | 'register') => void;
}

export const ArtistsPage: React.FC<ArtistsPageProps> = ({ onAuthOpen }) => {
  const { users, artworks, followArtist, currentUser } = useStore();
  const navigate = useNavigate();
  const [activeCat, setActiveCat] = useState('All');

  const artists = users.filter(u => u.role === 'artist' && !u.banned);
  const cats = ['All', ...Array.from(new Set(artists.map(a => a.cat || '').filter(Boolean)))];
  const filtered = activeCat === 'All' ? artists : artists.filter(a => a.cat === activeCat);

  const handleFollow = (e: React.MouseEvent, artistId: string) => {
    e.stopPropagation();
    if (!currentUser) { onAuthOpen('login'); return; }
    followArtist(artistId);
  };

  return (
    <div className="page active">
      <div className="con" style={{ paddingTop: 36, paddingBottom: 60 }}>
        <div className="sec-head">
          <h2 className="sec-title">Discover <span className="rb-text">Artists</span></h2>
        </div>
        <div className="cat-pills">
          {cats.map(c => (
            <button key={c} className={`cpill ${activeCat === c ? 'on' : ''}`} onClick={() => setActiveCat(c)}>{c}</button>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(260px,1fr))', gap: 18 }}>
          {filtered.map(artist => {
            const works = artworks.filter(a => a.artistId === artist.id);
            const isFollowing = currentUser && (artist.followers || []).includes(currentUser.id);
            return (
              <div
                key={artist.id}
                style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden', transition: '.3s', cursor: 'pointer' }}
                className="art-card"
                onClick={() => navigate(`/artists/${artist.id}`)}
              >
                <div style={{ height: 100, background: artGrad(artist.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 44 }}>
                  {artist.avatar
                    ? <img src={artist.avatar} alt="" style={{ width: 80, height: 80, borderRadius: '50%', objectFit: 'cover', border: '3px solid rgba(255,255,255,.2)' }} />
                    : (artist.emoji || '🎨')}
                </div>
                <div style={{ padding: '16px 18px' }}>
                  <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 4 }}>{artist.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10 }}>{artist.cat || 'Artist'} · {works.length} works · {(artist.followers || []).length} followers</div>
                  {artist.bio && <div style={{ fontSize: 12.5, color: 'var(--muted)', lineHeight: 1.6, marginBottom: 14 }}>{artist.bio.slice(0, 80)}…</div>}
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="follow-btn" style={{ flex: 1 }}
                      onClick={e => handleFollow(e, artist.id)}>
                      {isFollowing ? '✓ Following' : '+ Follow'}
                    </button>
                    <button className="msg-btn-p" onClick={e => { e.stopPropagation(); navigate(`/artists/${artist.id}`); }}>View</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
