import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import type { Event } from '../types';

const fmtInr = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const fmtDate = (s: string) => new Date(s).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

type AdminTab = 'dash' | 'users' | 'artists' | 'artworks' | 'orders' | 'events' | 'reports';

export const AdminDashboard: React.FC = () => {
  const { currentUser, users, artworks, orders, events, reports, removeArtwork, banUser, unbanUser, deleteUser, warnUser, approveArtwork, rejectArtwork, updateReportStatus, removeEvent, addEvent } = useStore();
  const navigate = useNavigate();
  const [tab, setTab] = useState<AdminTab>('dash');
  const [toast, setToast] = useState('');
  const [newEventForm, setNewEventForm] = useState({ title: '', type: 'workshop', date: '', loc: '', fee: '', seats: '', description: '' });
  const [showNewEvent, setShowNewEvent] = useState(false);

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  if (!currentUser || currentUser.role !== 'admin') {
    return (
      <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '70vh' }}>
        <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🔒</div>
          <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 16 }}>Admin Access Only</div>
          <button className="btn-rb" onClick={() => navigate('/')}>Go Home</button>
        </div>
      </div>
    );
  }

  const totalRevenue = orders.reduce((s, o) => s + o.amount, 0);
  const artistUsers = users.filter(u => u.role === 'artist');
  const buyerUsers = users.filter(u => u.role === 'buyer');
  const revChart = [120, 80, 200, 150, 340, 220, 290];
  const maxRev = Math.max(...revChart);

  const SIDEBAR_ITEMS: { id: AdminTab; label: string; icon: string }[] = [
    { id: 'dash', label: 'Dashboard', icon: '📊' },
    { id: 'users', label: 'Users', icon: '👥' },
    { id: 'artists', label: 'Artists', icon: '🎨' },
    { id: 'artworks', label: 'Artworks', icon: '🖼' },
    { id: 'orders', label: 'Orders', icon: '📦' },
    { id: 'events', label: 'Events', icon: '📢' },
    { id: 'reports', label: 'Reports', icon: '🚨' },
  ];

  const exportCSV = () => {
    const csv = 'Name,Email,Role,Joined\n' + users.map(u => `${u.name},${u.email},${u.role},${u.joinedAt || ''}`).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const a = document.createElement('a'); a.href = url; a.download = 'atrium-users.csv'; a.click();
    URL.revokeObjectURL(url);
    showToast('Users exported 📊');
  };

  const handleAddEvent = () => {
    if (!newEventForm.title || !newEventForm.date) { showToast('Title and date are required'); return; }
    addEvent({
      title: newEventForm.title,
      type: newEventForm.type as Event['type'],
      artistId: currentUser.id,
      date: newEventForm.date,
      loc: newEventForm.loc,
      fee: +newEventForm.fee || 0,
      seats: +newEventForm.seats || 0,
      description: newEventForm.description,
      status: 'active',
    });
    setShowNewEvent(false);
    setNewEventForm({ title: '', type: 'workshop', date: '', loc: '', fee: '', seats: '', description: '' });
    showToast('✅ Event created!');
  };

  return (
    <div className="page active">
      {toast && (
        <div style={{ position: 'fixed', bottom: 22, right: 22, zIndex: 9500, padding: '13px 18px', borderRadius: 13, background: 'var(--card)', border: '1px solid rgba(107,203,119,.4)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 9, boxShadow: 'var(--shadow)' }}>
          ✅ {toast}
        </div>
      )}
      <div className="admin-layout">
        {/* Sidebar */}
        <div className="admin-sb">
          <div className="asb-logo">ATRIUM ADMIN</div>
          <div className="asb-grp">Overview</div>
          {SIDEBAR_ITEMS.slice(0, 4).map(item => (
            <div key={item.id} className={`asb-item ${tab === item.id ? 'on' : ''}`} onClick={() => setTab(item.id)}>
              {item.icon} {item.label}
            </div>
          ))}
          <div className="asb-grp">Commerce</div>
          {SIDEBAR_ITEMS.slice(4, 6).map(item => (
            <div key={item.id} className={`asb-item ${tab === item.id ? 'on' : ''}`} onClick={() => setTab(item.id)}>
              {item.icon} {item.label}
            </div>
          ))}
          <div className="asb-grp">Tools</div>
          {SIDEBAR_ITEMS.slice(6).map(item => (
            <div key={item.id} className={`asb-item ${tab === item.id ? 'on' : ''}`} onClick={() => setTab(item.id)}>
              {item.icon} {item.label}
            </div>
          ))}
        </div>

        {/* Main content */}
        <div className="admin-main">

          {/* === DASHBOARD === */}
          {tab === 'dash' && (
            <div>
              <div className="ap-title">Dashboard</div>
              <div className="ap-sub">Welcome, {currentUser.name} · Live data</div>
              <div className="kpi-row">
                {[
                  { l: 'Total Revenue', v: fmtInr(totalRevenue), c: '↑ All time', grad: 'linear-gradient(135deg,#ffd93d,#ff9a3c)' },
                  { l: 'Total Artists', v: artistUsers.length, c: '↑ Active', grad: 'linear-gradient(135deg,#c77dff,#4d96ff)' },
                  { l: 'Total Orders', v: orders.length, c: '↑ Sales', grad: 'linear-gradient(135deg,#6bcb77,#4d96ff)' },
                  { l: 'Artworks Listed', v: artworks.length, c: `${artworks.filter(a => !a.sold).length} available`, grad: 'linear-gradient(135deg,#ff9a3c,#ff6b6b)' },
                  { l: 'Total Users', v: users.length, c: `${buyerUsers.length} buyers`, grad: 'linear-gradient(135deg,#ff6bbb,#c77dff)' },
                  { l: 'Active Events', v: events.filter(e => e.status === 'active').length, c: 'Ongoing', grad: 'linear-gradient(135deg,#4d96ff,#6bcb77)' },
                ].map(k => (
                  <div key={k.l} className="kpi">
                    <div className="kpi-l">{k.l}</div>
                    <div className="kpi-v" style={{ background: k.grad, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>{k.v}</div>
                    <div className="kpi-ch up">{k.c}</div>
                  </div>
                ))}
              </div>
              {/* Revenue Chart */}
              <div className="a-tbl" style={{ marginBottom: 20 }}>
                <div className="a-th"><div className="a-tt">Revenue — Last 7 Days</div></div>
                <div style={{ padding: 14 }}>
                  <div className="chart-wrap">
                    {revChart.map((v, i) => (
                      <div key={i} className="chart-bar" style={{ height: `${(v / maxRev) * 100}%` }} title={`Day ${i + 1}: ${fmtInr(v * 1000)}`} />
                    ))}
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 8, fontSize: 10, color: 'var(--muted)' }}>
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => <span key={d}>{d}</span>)}
                  </div>
                </div>
              </div>
              {/* 2-col: Recent Orders + Artist Applications */}
              <div className="admin-2col">
                <div className="a-tbl">
                  <div className="a-th"><div className="a-tt">Recent Orders</div></div>
                  <table>
                    <thead><tr><th>Order</th><th>Item</th><th>Amount</th><th>Status</th></tr></thead>
                    <tbody>
                      {orders.length === 0
                        ? <tr><td colSpan={4} style={{ textAlign: 'center', color: 'var(--muted)', padding: 20 }}>No orders yet</td></tr>
                        : orders.slice(-4).reverse().map(o => {
                            const art = artworks.find(a => a.id === o.artId);
                            return (
                              <tr key={o.id}>
                                <td style={{ fontFamily: 'monospace', fontSize: 11 }}>{o.id}</td>
                                <td>{art?.title?.slice(0, 16) || 'Unknown'}…</td>
                                <td>{fmtInr(o.amount)}</td>
                                <td><span className="pill p-ok">{o.status}</span></td>
                              </tr>
                            );
                          })}
                    </tbody>
                  </table>
                </div>
                <div className="a-tbl">
                  <div className="a-th"><div className="a-tt">Artist Applications</div></div>
                  <table>
                    <thead><tr><th>Name</th><th>Style</th><th>Action</th></tr></thead>
                    <tbody>
                      {artistUsers.slice(0, 4).map(a => (
                        <tr key={a.id}>
                          <td>{a.name}</td>
                          <td>{a.cat || '—'}</td>
                          <td><button className="a-btn a-btn-ok" onClick={() => showToast(`${a.name} approved ✅`)}>Approve</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* === USERS === */}
          {tab === 'users' && (
            <div>
              <div className="ap-title">User Management</div>
              <div className="ap-sub">All Users ({users.length})</div>
              <div className="a-tbl">
                <div className="a-th">
                  <div className="a-tt">All Users</div>
                  <button className="a-btn a-btn-view" onClick={exportCSV}>Export CSV</button>
                </div>
                <table>
                  <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.id}>
                        <td style={{ fontWeight: 600 }}>{u.name}</td>
                        <td style={{ fontSize: 11.5, color: 'var(--muted)' }}>{u.email}</td>
                        <td><span className={`pill ${u.role === 'admin' ? 'p-pend' : u.role === 'artist' ? 'p-ok' : 'p-bad'}`}>{u.role}</span></td>
                        <td>{u.joinedAt ? fmtDate(u.joinedAt) : '—'}</td>
                        <td><span className={`pill ${u.banned ? 'p-bad' : 'p-ok'}`}>{u.banned ? 'Banned' : 'Active'}</span></td>
                        <td>
                          {u.role === 'artist' && (
                            <button className="a-btn a-btn-view" onClick={() => navigate(`/artists/${u.id}`)}>Profile</button>
                          )}
                          {u.banned
                            ? <button className="a-btn a-btn-ok" onClick={() => { unbanUser(u.id); showToast(`${u.name} unbanned`); }}>Unban</button>
                            : <button className="a-btn a-btn-bad" onClick={() => { banUser(u.id); showToast(`${u.name} suspended`); }}>Ban</button>}
                          <button className="a-btn a-btn-bad" style={{ marginLeft: 6, background: 'var(--bg3)', color: 'var(--muted)' }} onClick={() => { if(window.confirm('Permanently delete user?')) { deleteUser(u.id); showToast('User deleted'); } }}>Delete</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* === ARTISTS === */}
          {tab === 'artists' && (
            <div>
              <div className="ap-title">Artist Management</div>
              <div className="ap-sub">All Artists ({artistUsers.length})</div>
              <div className="a-tbl">
                <table>
                  <thead><tr><th>Artist</th><th>Category</th><th>Works</th><th>Followers</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    {artistUsers.map(a => {
                      const works = artworks.filter(x => x.artistId === a.id).length;
                      return (
                        <tr key={a.id}>
                          <td>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                              <div style={{ width: 34, height: 34, borderRadius: '50%', background: artGrad(a.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, overflow: 'hidden' }}>
                                {a.avatar ? <img src={a.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (a.emoji || a.name[0])}
                              </div>
                              {a.name}
                            </div>
                          </td>
                          <td>{a.cat || '—'}</td>
                          <td>{works}</td>
                          <td>{(a.followers || []).length}</td>
                          <td><span className={`pill ${a.banned ? 'p-bad' : 'p-ok'}`}>{a.banned ? 'Banned' : 'Active'}</span></td>
                          <td>
                            <button className="a-btn a-btn-view" onClick={() => navigate(`/artists/${a.id}`)}>Profile</button>
                            {a.banned
                              ? <button className="a-btn a-btn-ok" onClick={() => { unbanUser(a.id); showToast(`${a.name} unbanned`); }}>Unban</button>
                              : <button className="a-btn a-btn-bad" onClick={() => { banUser(a.id); showToast(`${a.name} suspended`); }}>Ban</button>}
                            <button className="a-btn a-btn-bad" style={{ marginLeft: 6, background: 'var(--bg3)', color: 'var(--muted)' }} onClick={() => { if(window.confirm('Permanently delete artist?')) { deleteUser(a.id); showToast('Artist deleted'); } }}>Delete</button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* === ARTWORKS === */}
          {tab === 'artworks' && (
            <div>
              <div className="ap-title">Artwork Listings</div>
              <div className="ap-sub">All Artworks ({artworks.length})</div>
              <div className="a-tbl">
                <table>
                  <thead><tr><th>Image</th><th>Title</th><th>Artist</th><th>Category</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    {artworks.map(a => {
                      const artist = users.find(u => u.id === a.artistId);
                      return (
                        <tr key={a.id}>
                          <td>
                            <div style={{ width: 40, height: 40, borderRadius: 8, background: artGrad(a.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, overflow: 'hidden' }}>
                              {a.image ? <img src={a.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (a.emoji || '🖼️')}
                            </div>
                          </td>
                          <td style={{ fontWeight: 600 }}>{a.title}</td>
                          <td>{artist?.name || 'Unknown'}</td>
                          <td>{a.cat}</td>
                          <td>{fmtInr(a.price)}</td>
                          <td>
                            {a.status === 'pending' ? <span className="pill p-pend">Pending</span> : 
                             a.status === 'rejected' ? <span className="pill p-bad">Rejected</span> :
                             <span className={`pill ${a.sold ? 'p-bad' : 'p-ok'}`}>{a.sold ? 'Sold' : 'Approved'}</span>}
                          </td>
                          <td style={{ display: 'flex', gap: 6 }}>
                            {a.status === 'pending' && (
                              <>
                                <button className="a-btn a-btn-ok" onClick={() => { approveArtwork(a.id); showToast('Approved'); }}>Approve</button>
                                <button className="a-btn a-btn-bad" onClick={() => { const r = prompt('Reason for rejection?'); if(r) { rejectArtwork(a.id, r); showToast('Rejected'); } }}>Reject</button>
                              </>
                            )}
                            <button className="a-btn a-btn-bad" onClick={() => { removeArtwork(a.id); showToast('Artwork removed'); }}>Remove</button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* === ORDERS === */}
          {tab === 'orders' && (
            <div>
              <div className="ap-title">Orders</div>
              <div className="ap-sub">All Orders ({orders.length})</div>
              <div className="a-tbl">
                <table>
                  <thead><tr><th>Order ID</th><th>Buyer</th><th>Item</th><th>Amount</th><th>Date</th><th>Status</th></tr></thead>
                  <tbody>
                    {orders.length === 0
                      ? <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--muted)', padding: 20 }}>No orders yet</td></tr>
                      : orders.slice().reverse().map(o => {
                          const art = artworks.find(a => a.id === o.artId);
                          const buyer = users.find(u => u.id === o.buyerId);
                          return (
                            <tr key={o.id}>
                              <td style={{ fontFamily: 'monospace', fontSize: 11 }}>{o.id}</td>
                              <td>{buyer?.name || 'Unknown'}</td>
                              <td>{art?.title || 'Unknown'}</td>
                              <td>{fmtInr(o.amount)}</td>
                              <td>{fmtDate(o.date)}</td>
                              <td><span className="pill p-ok">{o.status}</span></td>
                            </tr>
                          );
                        })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* === EVENTS === */}
          {tab === 'events' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
                <div>
                  <div className="ap-title">Events &amp; Announcements</div>
                  <div className="ap-sub">Review and manage events</div>
                </div>
                <button className="btn-rb" style={{ padding: '9px 18px', fontSize: 13 }} onClick={() => setShowNewEvent(true)}>+ New Event</button>
              </div>

              {/* New Event Form */}
              {showNewEvent && (
                <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 24, marginBottom: 24 }}>
                  <h4 style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, marginBottom: 18 }}>Create New Event</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                    <div className="fg-m"><label>Title *</label><input type="text" value={newEventForm.title} onChange={e => setNewEventForm(f => ({ ...f, title: e.target.value }))} placeholder="Event title" /></div>
                    <div className="fg-m">
                      <label>Type</label>
                      <select value={newEventForm.type} onChange={e => setNewEventForm(f => ({ ...f, type: e.target.value }))}>
                        <option value="workshop">Workshop</option>
                        <option value="exhibition">Exhibition</option>
                        <option value="online">Online</option>
                        <option value="sale">Sale</option>
                        <option value="announcement">Announcement 📢</option>
                      </select>
                    </div>
                    <div className="fg-m"><label>Date *</label><input type="date" value={newEventForm.date} onChange={e => setNewEventForm(f => ({ ...f, date: e.target.value }))} /></div>
                    <div className="fg-m"><label>Location</label><input type="text" value={newEventForm.loc} onChange={e => setNewEventForm(f => ({ ...f, loc: e.target.value }))} placeholder="City or Online" /></div>
                    <div className="fg-m"><label>Fee (₹, 0 = Free)</label><input type="number" value={newEventForm.fee} onChange={e => setNewEventForm(f => ({ ...f, fee: e.target.value }))} /></div>
                    <div className="fg-m"><label>Max Seats (0 = Unlimited)</label><input type="number" value={newEventForm.seats} onChange={e => setNewEventForm(f => ({ ...f, seats: e.target.value }))} /></div>
                  </div>
                  <div className="fg-m"><label>Description</label><textarea value={newEventForm.description} onChange={e => setNewEventForm(f => ({ ...f, description: e.target.value }))} placeholder="Event details…" /></div>
                  <div style={{ display: 'flex', gap: 10 }}>
                    <button className="sub-btn" style={{ maxWidth: 180 }} onClick={handleAddEvent}>Create Event</button>
                    <button className="t-dl" onClick={() => setShowNewEvent(false)}>Cancel</button>
                  </div>
                </div>
              )}

              <div className="a-tbl">
                <table>
                  <thead><tr><th>Title</th><th>Artist</th><th>Type</th><th>Date</th><th>Regs</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    {events.map(ev => {
                      const artist = users.find(u => u.id === ev.artistId);
                      return (
                        <tr key={ev.id}>
                          <td style={{ fontWeight: 600 }}>{ev.title}</td>
                          <td>{artist?.name || 'Atrium'}</td>
                          <td><span className="pill p-ok">{ev.type}</span></td>
                          <td>{fmtDate(ev.date)}</td>
                          <td>{(ev.regs || []).length}{ev.seats > 0 ? `/${ev.seats}` : ''}</td>
                          <td><span className={`pill ${ev.status === 'active' ? 'p-ok' : 'p-pend'}`}>{ev.status}</span></td>
                          <td>
                            <button className="a-btn a-btn-bad" onClick={() => { removeEvent(ev.id); showToast('Event removed'); }}>Remove</button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* === REPORTS === */}
          {tab === 'reports' && (
            <div>
              <div className="ap-title">Moderation &amp; Reports</div>
              <div className="ap-sub">Review flagged content and pending investigations</div>
              <div className="a-tbl">
                <div className="a-th"><div className="a-tt">Active Reports</div></div>
                <table>
                  <thead><tr><th>Target Type</th><th>Target ID</th><th>Reason</th><th>Description</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    {reports.length === 0 ? (
                      <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--muted)', padding: 20 }}>No active reports. Platform is healthy.</td></tr>
                    ) : (
                      reports.slice().reverse().map(r => (
                        <tr key={r.id}>
                          <td><span className={`pill ${r.targetType === 'artist' ? 'p-ok' : 'p-pend'}`}>{r.targetType.toUpperCase()}</span></td>
                          <td style={{ fontFamily: 'monospace', fontSize: 11 }}>{r.targetId.slice(0, 8)}</td>
                          <td style={{ fontWeight: 600 }}>{r.reason}</td>
                          <td style={{ fontSize: 12 }}>{r.description.length > 30 ? r.description.slice(0, 30) + '...' : r.description}</td>
                          <td><span className={`pill ${r.status === 'pending' ? 'p-bad' : r.status === 'investigating' ? 'p-pend' : 'p-ok'}`}>{r.status}</span></td>
                          <td style={{ display: 'flex', gap: 6 }}>
                            {r.status !== 'resolved' && r.status !== 'dismissed' && (
                              <>
                                <button className="a-btn a-btn-view" onClick={() => updateReportStatus(r.id, 'investigating')}>Investigate</button>
                                <button className="a-btn a-btn-bad" onClick={() => { 
                                  if(r.targetType === 'artist') {
                                    const msg = window.prompt('Warning message to artist:');
                                    if(msg) { warnUser(r.targetId, msg); updateReportStatus(r.id, 'resolved'); showToast('Warning sent'); }
                                  } else {
                                    if(window.confirm('Remove this artwork?')) { removeArtwork(r.targetId); updateReportStatus(r.id, 'resolved'); showToast('Artwork removed'); }
                                  }
                                }}>Take Action</button>
                                <button className="a-btn a-btn-ok" onClick={() => { updateReportStatus(r.id, 'dismissed'); showToast('Report dismissed'); }}>Dismiss</button>
                              </>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              
              {/* Platform Stats */}
              <div className="a-tbl" style={{ marginTop: 20 }}>
                <div className="a-th"><div className="a-tt">Platform Health</div></div>
                <div style={{ padding: 20 }}>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px,1fr))', gap: 14 }}>
                    {[
                      { label: 'Pending Reports', value: reports.filter(r => r.status === 'pending').length, color: '#ff6b6b' },
                      { label: 'Pending Artworks', value: artworks.filter(a => a.status === 'pending').length, color: '#ffd93d' },
                      { label: 'Banned Users', value: users.filter(u => u.banned).length, color: '#c77dff' },
                      { label: 'Uptime', value: '99.9%', color: '#6bcb77' },
                    ].map(s => (
                      <div key={s.label} style={{ background: 'var(--bg3)', borderRadius: 12, padding: '16px 18px', border: '1px solid var(--border)' }}>
                        <div style={{ fontSize: 10.5, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', marginBottom: 6 }}>{s.label}</div>
                        <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 28, color: s.color }}>{s.value}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
