import React, { useState } from 'react';

import { useStore } from '../store/useStore';
import { EventCard } from '../components/EventCard';
import type { Event } from '../types';

export const EventsPage: React.FC = () => {
  const { events, users, registerEvent } = useStore();
  const [activeCat, setActiveCat] = useState('All');
  const [ticket, setTicket] = useState<{ event: Event; ticketId: string; seat: string } | null>(null);

  const types = ['All', 'workshop', 'exhibition', 'online', 'sale'];
  
  const approvedEvents = events.filter(e => {
    const artist = users.find(u => u.id === e.artistId);
    return !artist?.banned;
  });
  
  const filtered = activeCat === 'All' ? approvedEvents : approvedEvents.filter(e => e.type === activeCat);

  const handleRegister = (ev: Event) => {
    const result = registerEvent(ev.id);
    if (result.success && result.ticketId) {
      setTicket({ event: ev, ticketId: result.ticketId, seat: result.seat! });
    }
  };

  return (
    <div className="page active">
      <div className="con" style={{ paddingTop: 36, paddingBottom: 60 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 26, flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h2 className="sec-title">Workshops &amp; <span className="rb-text">Events</span></h2>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>Discover workshops, exhibitions and events by Atrium artists</p>
          </div>
        </div>
        <div className="cat-pills">
          {types.map(t => (
            <button key={t} className={`cpill ${activeCat === t ? 'on' : ''}`} onClick={() => setActiveCat(t)}>
              {t === 'All' ? 'All' : t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>
        <div className="ann-grid">
          {filtered.length > 0 ? filtered.map(ev => (
            <EventCard key={ev.id} event={ev} onRegister={handleRegister} />
          )) : (
            <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: 60, color: 'var(--muted)' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📢</div>
              <div>No events found</div>
            </div>
          )}
        </div>
      </div>

      {/* Ticket Modal */}
      {ticket && (
        <div className="ticket-overlay open" onClick={() => setTicket(null)}>
          <div onClick={e => e.stopPropagation()}>
            <div className="ticket-wrap">
              <div className="ticket">
                <div className="ticket-hdr">
                  <div className="t-logo">ATRIUM</div>
                  <div className="t-event">{ticket.event.title}</div>
                  <div className="t-artist">by {useStore.getState().users.find(u => u.id === ticket.event.artistId)?.name || 'Atrium'}</div>
                </div>
                <div className="t-perf"><div className="t-dash"></div></div>
                <div className="t-body">
                  <div className="t-meta">
                    <div className="t-mi"><div className="tlbl">Date</div><div className="tval">{new Date(ticket.event.date).toLocaleDateString('en-IN')}</div></div>
                    <div className="t-mi"><div className="tlbl">Venue</div><div className="tval">{ticket.event.loc || 'TBA'}</div></div>
                    <div className="t-mi"><div className="tlbl">Attendee</div><div className="tval">{useStore.getState().currentUser?.name}</div></div>
                    <div className="t-mi"><div className="tlbl">Fee</div><div className="tval">{ticket.event.fee > 0 ? `₹${ticket.event.fee}` : 'Free'}</div></div>
                  </div>
                  <div className="qr-box">
                    <div style={{ width: 80, height: 80, background: '#fff', padding: 6, borderRadius: 8, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 2 }}>
                      {Array.from({ length: 16 }).map((_, i) => (
                        <div key={i} style={{ background: (ticket.ticketId.charCodeAt(i % ticket.ticketId.length) + i) % 2 === 0 ? '#000' : 'transparent', borderRadius: 1 }} />
                      ))}
                    </div>
                    <div className="qr-note" style={{ marginTop: 8 }}>Scan for Entry</div>
                  </div>
                  <div className="t-id">TICKET ID: {ticket.ticketId}</div>
                </div>
              </div>
              <div className="ticket-stub">
                <div className="stub-seat">
                  <div className="slbl">Seat</div>
                  <div className="sval">{ticket.seat}</div>
                </div>
                <div className="stub-ok">
                  <div className="ok-dot"></div>
                  <span>Confirmed</span>
                </div>
              </div>
              <div className="t-actions">
                <button className="t-done" onClick={() => setTicket(null)}>Done ✓</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
