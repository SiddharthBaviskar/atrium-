import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { ArtCard } from '../components/ArtCard';

export const ShopPage: React.FC = () => {
  const { artworks, users } = useStore();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [activeCat, setActiveCat] = useState('All');
  const [maxPrice, setMaxPrice] = useState(500000);
  const [availOnly, setAvailOnly] = useState(false);
  const [sort, setSort] = useState('feat');
  const [query, setQuery] = useState('');

  const maxPossible = Math.max(...artworks.map(a => a.price), 500000);
  const categories = ['All', ...Array.from(new Set(artworks.map(a => a.cat)))];

  useEffect(() => {
    const q = searchParams.get('q');
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (q) setQuery(q);
  }, [searchParams]);

  const filtered = artworks
    .filter(a => {
      const artist = users.find(u => u.id === a.artistId);
      if (artist?.banned) return false;
      if (a.status !== 'approved') return false;
      const matchCat = activeCat === 'All' || a.cat === activeCat;
      const matchPrice = a.price <= maxPrice;
      const matchAvail = !availOnly || !a.sold;
      const matchQuery = !query || a.title.toLowerCase().includes(query.toLowerCase()) ||
        a.cat.toLowerCase().includes(query.toLowerCase()) ||
        (artist?.name || '').toLowerCase().includes(query.toLowerCase());
      return matchCat && matchPrice && matchAvail && matchQuery;
    })
    .sort((a, b) => {
      if (sort === 'price-asc') return a.price - b.price;
      if (sort === 'price-desc') return b.price - a.price;
      if (sort === 'newest') return new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime();
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });

  const fmtInr = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

  return (
    <div className="page active">
      <div className="con">
        <div className="shop-layout">
          {/* Filters */}
          <aside className="filter-panel">
            <div className="fp-title">Filters</div>
            {query && (
              <div style={{ marginBottom: 16, padding: '8px 12px', background: 'var(--bg3)', borderRadius: 8, fontSize: 12.5 }}>
                Search: <strong>"{query}"</strong>
                <button onClick={() => setQuery('')} style={{ marginLeft: 8, color: 'var(--r1)', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12 }}>✕ Clear</button>
              </div>
            )}
            <div className="fg">
              <div className="fg-lbl">Category</div>
              <div className="fg-opts">
                {categories.map(c => (
                  <label key={c} className="fg-opt">
                    <input type="radio" name="cat" checked={activeCat === c} onChange={() => setActiveCat(c)} style={{ accentColor: '#c77dff' }} />
                    {c}
                  </label>
                ))}
              </div>
            </div>
            <div className="fg">
              <div className="fg-lbl">Max Price</div>
              <input type="range" min={0} max={maxPossible} value={maxPrice} onChange={e => setMaxPrice(+e.target.value)} />
              <div className="price-labels">
                <span>₹0</span>
                <span>{maxPrice >= maxPossible ? 'Any' : fmtInr(maxPrice)}</span>
              </div>
            </div>
            <div className="fg">
              <div className="fg-lbl">Availability</div>
              <div className="fg-opts">
                <label className="fg-opt">
                  <input type="checkbox" checked={availOnly} onChange={e => setAvailOnly(e.target.checked)} />
                  Available Only
                </label>
              </div>
            </div>
          </aside>

          {/* Main Grid */}
          <div className="shop-main">
            <div className="toolbar">
              <span className="res-txt">{filtered.length} artworks{query ? ` for "${query}"` : ''}</span>
              <select className="sort-sel" value={sort} onChange={e => setSort(e.target.value)}>
                <option value="feat">Featured</option>
                <option value="price-asc">Price: Low → High</option>
                <option value="price-desc">Price: High → Low</option>
                <option value="newest">Newest First</option>
              </select>
            </div>
            <div className="art-grid">
              {filtered.length > 0 ? filtered.map(art => (
                <ArtCard
                  key={art.id}
                  art={art}
                  artist={users.find(u => u.id === art.artistId)}
                  onArtistClick={id => navigate(`/artists/${id}`)}
                  onCardClick={art => navigate(`/artwork/${art.id}`)}
                />
              )) : (
                <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: 60, color: 'var(--muted)' }}>
                  <div style={{ fontSize: 48, marginBottom: 12 }}>🔍</div>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>No artworks found</div>
                  <div style={{ fontSize: 13, marginTop: 6 }}>Try adjusting your filters</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
