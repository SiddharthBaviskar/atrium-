import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useStore } from '../store/useStore';

const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

const makeConvId = (a: string, b: string) => [a, b].sort().join('__');

const timeAgo = (iso: string) => {
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return Math.floor(diff / 60000) + 'm ago';
  if (diff < 86400000) return Math.floor(diff / 3600000) + 'h ago';
  return Math.floor(diff / 86400000) + 'd ago';
};

export const MessagesPage: React.FC = () => {
  const { currentUser, users, messages, sendMessage, markConvRead } = useStore();
  const navigate = useNavigate();
  const location = useLocation();

  const [activeConv, setActiveConv] = useState<string | null>(null);
  const [activeOtherId, setActiveOtherId] = useState<string | null>(null);
  const [msgText, setMsgText] = useState('');
  const [search, setSearch] = useState('');
  const bodyRef = useRef<HTMLDivElement>(null);

  const state = location.state as { toId?: string } | null;

  useEffect(() => {
    if (!currentUser) { navigate('/'); return; }
    if (state?.toId) {
      const cid = makeConvId(currentUser.id, state.toId);
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setActiveConv(cid);
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setActiveOtherId(state.toId);
    }
  }, [currentUser, state, navigate]);

  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [messages, activeConv]);

  if (!currentUser) return null;

  // Build conversations list
  const convIds = Object.keys(messages).filter(cid => cid.split('__').includes(currentUser.id));
  const convs = convIds.map(cid => {
    const parts = cid.split('__');
    const otherId = parts[0] === currentUser.id ? parts[1] : parts[0];
    const other = users.find(u => u.id === otherId);
    if (!other || other.banned) return null;
    const hist = messages[cid] || [];
    const last = hist[hist.length - 1];
    const unread = hist.filter(m => m.fromId !== currentUser.id && !m.read).length;
    if (search && !other.name.toLowerCase().includes(search.toLowerCase())) return null;
    return { cid, other, last, unread };
  }).filter(Boolean).sort((a, b) => new Date((b!.last?.at) || 0).getTime() - new Date((a!.last?.at) || 0).getTime());

  const openConv = (cid: string, otherId: string) => {
    setActiveConv(cid);
    setActiveOtherId(otherId);
    markConvRead(cid);
  };

  const handleSend = () => {
    if (!activeOtherId || !msgText.trim()) return;
    sendMessage(activeOtherId, msgText);
    setMsgText('');
  };

  const activeMessages = activeConv ? (messages[activeConv] || []) : [];
  const activeOther = users.find(u => u.id === activeOtherId);

  return (
    <div className="page active" style={{ paddingTop: 63 }}>
      <div className="msg-layout">
        {/* Sidebar */}
        <div className="msg-sidebar">
          <div className="msg-sb-hd">
            <h3>Messages</h3>
            <input className="msg-srch" type="text" placeholder="Search conversations…" value={search} onChange={e => setSearch(e.target.value)} />
            <button className="compose-btn" onClick={() => {}}>✏ New Message</button>
          </div>
          <div className="conv-list">
            {convs.length === 0 ? (
              <div style={{ padding: 24, textAlign: 'center', color: 'var(--muted)', fontSize: 13 }}>
                No conversations yet.<br /><br />Message an artist to get started!
              </div>
            ) : convs.map(c => c && (
              <div key={c.cid} className={`conv-item ${activeConv === c.cid ? 'on' : ''}`} onClick={() => openConv(c.cid, c.other.id)}>
                <div className="c-av" style={{ background: artGrad(c.other.id) }}>
                  {c.other.avatar
                    ? <img src={c.other.avatar} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                    : (c.other.emoji || c.other.name[0])}
                </div>
                <div className="c-body">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div className="c-name">{c.other.name}</div>
                    <div className="c-time">{c.last ? timeAgo(c.last.at) : ''}</div>
                  </div>
                  <div className="c-prev">{c.last ? c.last.text.slice(0, 40) : 'No messages yet'}</div>
                </div>
                {c.unread > 0 && <div className="c-unread">{c.unread}</div>}
              </div>
            ))}
          </div>
        </div>

        {/* Main chat area */}
        <div className="msg-main">
          {activeConv && activeOther ? (
            <>
              <div className="msg-main-hd">
                <div className="c-av" style={{ background: artGrad(activeOther.id), width: 38, height: 38, fontSize: 13 }}>
                  {activeOther.avatar
                    ? <img src={activeOther.avatar} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                    : (activeOther.emoji || activeOther.name[0])}
                </div>
                <div>
                  <h4>{activeOther.name}</h4>
                  <div className="online-ind">Online</div>
                </div>
              </div>
              <div className="msg-body" ref={bodyRef}>
                {activeMessages.length === 0 ? (
                  <div style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 13, margin: 'auto' }}>Say hello! 👋</div>
                ) : activeMessages.map(m => {
                  const isOwn = m.fromId === currentUser.id;
                  const sender = users.find(u => u.id === m.fromId);
                  return (
                    <div key={m.id} className={`msg-row ${isOwn ? 'own' : ''}`}>
                      {!isOwn ? (
                        <div className="c-av" style={{ background: artGrad(m.fromId), width: 28, height: 28, fontSize: 10, flexShrink: 0 }}>
                          {sender?.emoji || sender?.name[0]}
                        </div>
                      ) : <div style={{ width: 28, flexShrink: 0 }}></div>}
                      <div>
                        <div className="bubble">{m.text}</div>
                        <div className="msg-ts">{timeAgo(m.at)}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="msg-in-row">
                <input
                  className="msg-in"
                  type="text"
                  placeholder="Type a message…"
                  value={msgText}
                  onChange={e => setMsgText(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSend()}
                />
                <button className="send-btn" onClick={handleSend}>
                  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path d="m22 2-11 11M22 2 15 22l-4-9-9-4 20-7z"/>
                  </svg>
                </button>
              </div>
            </>
          ) : (
            <div className="msg-empty-state">
              <div style={{ fontSize: 48 }}>💬</div>
              <div style={{ fontSize: 15, fontWeight: 600 }}>Your Messages</div>
              <div style={{ fontSize: 13 }}>Select a conversation or start a new one</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
