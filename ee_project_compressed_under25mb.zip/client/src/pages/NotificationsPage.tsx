import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';

const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

export const NotificationsPage: React.FC = () => {
  const { currentUser, notifications, markNotifRead, clearNotifications } = useStore();
  const navigate = useNavigate();

  if (!currentUser) {
    return (
      <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '70vh' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🔔</div>
          <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 16 }}>Sign in to see notifications</div>
          <button className="btn-rb" onClick={() => navigate('/')}>Go Home</button>
        </div>
      </div>
    );
  }

  const userNotifs = notifications.filter(n => n.userId === currentUser.id);

  return (
    <div className="page active">
      <div className="con" style={{ paddingTop: 36, paddingBottom: 60, maxWidth: 800 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 28 }}>
          <div>
            <h2 className="sec-title">All <span className="rb-text">Notifications</span></h2>
            <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 4 }}>Stay updated with your latest activities</p>
          </div>
          <button className="nb ghost" onClick={clearNotifications}>Clear All</button>
        </div>

        {userNotifs.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '100px 20px', color: 'var(--muted)', background: 'var(--card)', borderRadius: 20, border: '1px solid var(--border)' }}>
            <div style={{ fontSize: 56, marginBottom: 16 }}>🔔</div>
            <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>No notifications yet</div>
            <div style={{ fontSize: 13 }}>We'll notify you here when something important happens</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {userNotifs.map(n => (
              <div 
                key={n.id} 
                className={`notif-card ${!n.read ? 'unread' : ''}`}
                style={{ 
                  background: 'var(--card)', 
                  borderRadius: 16, 
                  border: '1px solid var(--border)', 
                  padding: 20, 
                  display: 'flex', 
                  gap: 16, 
                  alignItems: 'center',
                  cursor: 'pointer',
                  transition: '.2s',
                  position: 'relative',
                  opacity: n.read ? 0.8 : 1,
                  boxShadow: !n.read ? '0 4px 20px rgba(199,125,255,.1)' : 'none'
                }}
                onClick={() => {
                  markNotifRead(n.id);
                  if (n.link) navigate(n.link);
                }}
              >
                {!n.read && <div style={{ position: 'absolute', top: 20, right: 20, width: 8, height: 8, borderRadius: '50%', background: '#c77dff' }} />}
                <div style={{ width: 44, height: 44, borderRadius: '50%', background: artGrad(n.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>
                  {n.type === 'sale' ? '💰' : n.type === 'message' ? '💬' : n.type === 'follower' ? '👤' : n.type === 'event' ? '📢' : '🔔'}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2, color: 'var(--text)' }}>{n.title}</div>
                  <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.5 }}>{n.message}</div>
                  <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 8 }}>{new Date(n.at).toLocaleString()}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
