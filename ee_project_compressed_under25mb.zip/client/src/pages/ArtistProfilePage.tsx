import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';

const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

interface ArtistProfilePageProps {
  onAuthOpen: (mode: 'login' | 'register') => void;
}

export const ArtistProfilePage: React.FC<ArtistProfilePageProps> = ({ onAuthOpen }) => {
  const { id } = useParams<{ id: string }>();
  const { users, artworks, posts, orders, currentUser, followArtist, addReport } = useStore();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'posts' | 'gallery'>('posts');
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState('Inappropriate behavior');
  const [reportDesc, setReportDesc] = useState('');
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  const artist = users.find(u => u.id === id);
  if (!artist || (artist.banned && currentUser?.role !== 'admin')) return (
    <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
      <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>🔍</div>
        <div style={{ fontSize: 18, fontWeight: 600 }}>Artist not found</div>
        <button className="btn-rb" style={{ marginTop: 20 }} onClick={() => navigate('/artists')}>Browse Artists</button>
      </div>
    </div>
  );

  const artistWorks = artworks.filter(a => a.artistId === artist.id);
  const artistPosts = posts.filter(p => p.artistId === artist.id);
  const artistOrders = orders.filter(o => artistWorks.some(a => a.id === o.artId));
  const isFollowing = currentUser && (artist.followers || []).includes(currentUser.id);
  const isOwn = currentUser?.id === artist.id;

  const handleFollow = () => {
    if (!currentUser) { onAuthOpen('login'); return; }
    followArtist(artist.id);
  };

  const handleMessage = () => {
    if (!currentUser) { onAuthOpen('login'); return; }
    navigate('/messages', { state: { toId: artist.id } });
  };

  const handleReport = () => {
    if (!currentUser) return;
    if (!reportDesc.trim()) { showToast('Please add a description'); return; }
    addReport({
      reporterId: currentUser.id,
      targetType: 'artist',
      targetId: artist.id,
      reason: reportReason,
      description: reportDesc
    });
    setShowReport(false);
    setReportDesc('');
    showToast('Artist reported. Admin will review.');
  };

  return (
    <div className="page active">
      {toast && (
        <div style={{ position: 'fixed', bottom: 22, right: 22, zIndex: 9500, padding: '13px 18px', borderRadius: 13, background: 'var(--card)', border: '1px solid rgba(107,203,119,.4)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 9, boxShadow: 'var(--shadow)' }}>
          ✅ {toast}
        </div>
      )}
      {/* Banner */}
      <div className="profile-banner" style={{ background: artist.banner ? 'none' : artGrad(artist.id), height: artist.banner ? '300px' : '220px', overflow: 'hidden', position: 'relative' }}>
        {artist.banner ? (
          <img src={artist.banner} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : (
          <div className="banner-emoji">
            <span style={{ fontSize: 110, opacity: 0.18 }}>{artist.emoji || '🎨'}</span>
          </div>
        )}
        <div className="banner-overlay"></div>
      </div>

      {/* Header */}
      <div className="profile-hdr">
        <div className="profile-meta">
          <div className="p-av" style={{ background: artGrad(artist.id) }}>
            {artist.avatar
              ? <img src={artist.avatar} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
              : <span style={{ fontSize: 36 }}>{artist.emoji || artist.name[0]}</span>}
          </div>
          <div className="p-info">
            <div className="p-name">{artist.name}</div>
            <div className="p-bio">{artist.bio || 'Artist on Atrium'}</div>
            <div className="p-stats">
              <div><div className="ps-n">{(artist.followers || []).length}</div><div className="ps-l">Followers</div></div>
              <div><div className="ps-n">{artistWorks.length}</div><div className="ps-l">Artworks</div></div>
              <div><div className="ps-n">{artistOrders.length}</div><div className="ps-l">Sales</div></div>
            </div>
          </div>
          {!isOwn && (
            <div className="p-actions">
              <button className={`follow-btn ${isFollowing ? 'following' : ''}`} onClick={handleFollow}>
                {isFollowing ? '✓ Following' : '+ Follow'}
              </button>
              <button className="msg-btn-p" onClick={handleMessage}>Message</button>
              <button className="msg-btn-p" style={{ background: 'transparent', border: '1px solid var(--border)', color: 'var(--muted)' }} onClick={() => { if(!currentUser) onAuthOpen('login'); else setShowReport(true); }}>
                🚩 Report
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Report Modal inline */}
      {showReport && (
        <div style={{ padding: '0 24px', maxWidth: 1000, margin: '0 auto' }}>
          <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 20, marginTop: 20 }}>
            <h4 style={{ fontSize: 15, marginBottom: 14 }}>Report Artist</h4>
            <div className="fg-m">
              <label>Reason</label>
              <select value={reportReason} onChange={e => setReportReason(e.target.value)}>
                <option value="Inappropriate behavior">Inappropriate behavior</option>
                <option value="Fake account / Scam">Fake account / Scam</option>
                <option value="Stolen artwork">Stolen artwork</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div className="fg-m">
              <label>Description</label>
              <textarea value={reportDesc} onChange={e => setReportDesc(e.target.value)} placeholder="Provide details..." rows={3} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="sub-btn" onClick={handleReport} style={{ maxWidth: 200 }}>Submit Report</button>
              <button className="t-dl" onClick={() => setShowReport(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="profile-tabs">
        <div className={`p-tab ${activeTab === 'posts' ? 'on' : ''}`} onClick={() => setActiveTab('posts')}>Posts &amp; Achievements</div>
        <div className={`p-tab ${activeTab === 'gallery' ? 'on' : ''}`} onClick={() => setActiveTab('gallery')}>Gallery &amp; Shop</div>
      </div>

      <div className="profile-content">
        {/* Posts Tab */}
        {activeTab === 'posts' && (
          <div className="tab-pane on">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
              <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 20 }}>Posts &amp; Achievements</h3>
            </div>
            {artistPosts.length === 0 ? (
              <div style={{ textAlign: 'center', padding: 60, color: 'var(--muted)' }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📝</div>
                <div>No posts yet</div>
              </div>
            ) : (
              <div className="post-grid">
                {artistPosts.map(post => (
                  <div key={post.id} className="post-card">
                    <div className="post-img" style={{ background: artGrad(post.id) }}>
                      {post.tag === 'achievement' ? '🏆' : '📝'}
                    </div>
                    <div className="post-body">
                      <span className={`post-tag ${post.tag === 'achievement' ? 'pt-ach' : 'pt-post'}`}>
                        {post.tag === 'achievement' ? '🏆 Achievement' : '📝 Post'}
                      </span>
                      <div className="post-title">{post.title}</div>
                      <div className="post-text">{post.text}</div>
                      <div className="post-acts">
                        <button className="post-act">❤️ {post.likes}</button>
                        <button className="post-act">🔗 {post.shares} shares</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Gallery Tab */}
        {activeTab === 'gallery' && (
          <div className="tab-pane on">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 20 }}>Gallery for Sale</h3>
            </div>
            {artistWorks.length === 0 ? (
              <div style={{ textAlign: 'center', padding: 60, color: 'var(--muted)' }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🖼️</div>
                <div>No artworks yet</div>
              </div>
            ) : (
              <div className="art-grid">
                {artistWorks.map(art => (
                  <ArtCard
                    key={art.id}
                    art={art}
                    artist={artist}
                    onCardClick={art => navigate(`/artwork/${art.id}`)}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
