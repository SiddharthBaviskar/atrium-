import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';

const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

export const AccountPage: React.FC = () => {
  const { currentUser, updateProfile, orders, wishlist, cart, events } = useStore();
  const navigate = useNavigate();

  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editBio, setEditBio] = useState(currentUser?.bio || '');
  const [avatarPreview, setAvatarPreview] = useState<string | null>(currentUser?.avatar || null);
  const [bannerPreview, setBannerPreview] = useState<string | null>(currentUser?.banner || null);
  const [msg, setMsg] = useState('');
  const avatarRef = useRef<HTMLInputElement>(null);
  const bannerRef = useRef<HTMLInputElement>(null);

  if (!currentUser) {
    return (
      <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '70vh' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🔒</div>
          <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 16 }}>Please sign in</div>
          <button className="btn-rb" onClick={() => navigate('/')}>Go Home</button>
        </div>
      </div>
    );
  }

  const myOrders = orders.filter(o => o.buyerId === currentUser.id);
  const myTickets = events.flatMap(e => (e.regs || []).filter(r => r.userId === currentUser.id).map(r => ({ event: e, reg: r })));

  const showMsg = (m: string) => { setMsg(m); setTimeout(() => setMsg(''), 3000); };

  const handleSave = () => {
    if (!editName.trim()) { showMsg('❌ Name is required'); return; }
    updateProfile({ name: editName, bio: editBio, avatar: avatarPreview || undefined, banner: bannerPreview || undefined });
    showMsg('✅ Profile updated!');
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setAvatarPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setBannerPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const roleColors: Record<string, string> = { artist: 'rgba(199,125,255,.15)', admin: 'rgba(255,107,107,.15)', buyer: 'rgba(107,203,119,.15)' };
  const roleText: Record<string, string> = { artist: '#c77dff', admin: '#ff6b6b', buyer: '#6bcb77' };

  return (
    <div className="page active">
      <div className="con">
        <div className="account-wrap">
          <h2 className="sec-title" style={{ marginBottom: 4 }}>My <span className="rb-text">Account</span></h2>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 28 }}>Manage your Atrium profile and settings</p>

          {msg && (
            <div style={{ padding: '12px 16px', borderRadius: 10, background: msg.startsWith('✅') ? 'rgba(107,203,119,.12)' : 'rgba(255,107,107,.12)', border: `1px solid ${msg.startsWith('✅') ? 'rgba(107,203,119,.3)' : 'rgba(255,107,107,.3)'}`, marginBottom: 20, fontSize: 13, color: msg.startsWith('✅') ? '#6bcb77' : '#ff6b6b' }}>
              {msg}
            </div>
          )}

          {/* Profile Card */}
          <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 28, marginBottom: 18 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
              <div 
                style={{ width: 80, height: 80, borderRadius: '50%', background: artGrad(currentUser.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, fontWeight: 700, color: '#fff', flexShrink: 0, overflow: 'hidden', cursor: 'pointer', border: '3px solid rgba(199,125,255,.3)', position: 'relative' }}
                onClick={() => avatarRef.current?.click()}
              >
                {avatarPreview ? <img src={avatarPreview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (currentUser.emoji || currentUser.name[0])}
                <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0, transition: '.2s' }} className="av-hover">📸</div>
              </div>
              <input ref={avatarRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleAvatarUpload} />
              <div>
                <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, fontWeight: 700 }}>{currentUser.name}</div>
                <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 8 }}>{currentUser.email}</div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <span style={{ fontSize: 11, padding: '2px 9px', borderRadius: 8, display: 'inline-flex', fontWeight: 600, background: roleColors[currentUser.role], color: roleText[currentUser.role] }}>
                    {currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}
                  </span>
                  <button className="a-btn a-btn-view" style={{ padding: '2px 8px', fontSize: '10px' }} onClick={() => avatarRef.current?.click()}>Change Photo</button>
                </div>
              </div>
            </div>
            <div className="fg-m"><label>Full Name</label><input type="text" value={editName} onChange={e => setEditName(e.target.value)} /></div>
            
            {/* Banner Upload */}
            <div style={{ marginBottom: 20 }}>
              <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: 'var(--muted)', marginBottom: 8 }}>Profile Banner</label>
              <div 
                style={{ width: '100%', height: 100, borderRadius: 12, background: bannerPreview ? 'none' : artGrad(currentUser.id), border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', overflow: 'hidden', position: 'relative' }}
                onClick={() => bannerRef.current?.click()}
              >
                {bannerPreview ? <img src={bannerPreview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ color: 'var(--muted)', fontSize: 12 }}>Click to upload banner</span>}
              </div>
              <div style={{ marginTop: 10, display: 'flex', gap: 8 }}>
                <button className="a-btn a-btn-view" style={{ fontSize: 10 }} onClick={() => bannerRef.current?.click()}>Change Banner</button>
                {bannerPreview && <button className="a-btn a-btn-bad" style={{ fontSize: 10 }} onClick={() => setBannerPreview(null)}>Remove</button>}
              </div>
              <input ref={bannerRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleBannerUpload} />
            </div>

            <div className="fg-m"><label>Bio</label><textarea value={editBio} onChange={e => setEditBio(e.target.value)} placeholder="Tell the world about yourself…" /></div>
            <button className="sub-btn" style={{ maxWidth: 200 }} onClick={handleSave}>Save Changes</button>
          </div>

          {/* My Tickets */}
          {myTickets.length > 0 && (
            <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 24, marginBottom: 18 }}>
              <h4 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>My Event Tickets 🎟️</h4>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 12 }}>
                {myTickets.map(t => (
                  <div key={t.reg.ticketId} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'var(--bg3)', borderRadius: 12, padding: 16, border: '1px dashed rgba(199,125,255,.4)' }}>
                    <div>
                      <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)' }}>{t.event.title}</div>
                      <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>📅 {new Date(t.event.date).toLocaleDateString()} &nbsp;·&nbsp; 📍 {t.event.loc}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 11, textTransform: 'uppercase', color: 'var(--muted)', letterSpacing: 1 }}>Ticket ID</div>
                      <div style={{ fontFamily: 'monospace', fontSize: 15, color: '#c77dff', fontWeight: 700 }}>{t.reg.ticketId}</div>
                      {t.event.seats > 0 && <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>Seat: <strong style={{ color: '#fff' }}>{t.reg.seat}</strong></div>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick stats for buyer */}
          {currentUser.role === 'buyer' && (
            <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 24, marginBottom: 18 }}>
              <h4 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>Purchase Summary</h4>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 16 }}>
                {[
                  { label: 'Orders', value: myOrders.length },
                  { label: 'Wishlist', value: wishlist.length },
                  { label: 'In Cart', value: cart.length },
                ].map(s => (
                  <div key={s.label} style={{ background: 'var(--bg3)', borderRadius: 10, padding: '14px 16px', textAlign: 'center', border: '1px solid var(--border)' }}>
                    <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 26, background: 'linear-gradient(135deg,#c77dff,#4d96ff)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>{s.value}</div>
                    <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1 }}>{s.label}</div>
                  </div>
                ))}
              </div>
              <button className="nb out" onClick={() => navigate('/my-orders')}>View Order History →</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
