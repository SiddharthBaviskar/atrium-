import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';

const CATS = ['Digital Art', 'Oil Painting', 'Watercolor', 'Sculpture', 'Mixed Media', 'AI Art', 'Traditional', 'Photography'];
const fmtInr = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

export const ArtistDashboard: React.FC = () => {
  const { currentUser, artworks, orders, users, addArtwork, removeArtwork, updateProfile, notifications, markNotifRead, posts, addPost, events, addEvent } = useStore();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<'overview' | 'upload' | 'works' | 'profile' | 'notifications' | 'posts' | 'events'>('overview');
  const [newEventForm, setNewEventForm] = useState({ title: '', type: 'workshop', date: '', loc: '', fee: '', seats: '', description: '' });
  const [showNewEvent, setShowNewEvent] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', price: '', cat: CATS[0] });
  const [previewImg, setPreviewImg] = useState<string | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(currentUser?.avatar || null);
  const [bannerPreview, setBannerPreview] = useState<string | null>(currentUser?.banner || null);
  const [editBio, setEditBio] = useState(currentUser?.bio || '');
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editCat, setEditCat] = useState(currentUser?.cat || CATS[0]);
  const [uploadMsg, setUploadMsg] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const avatarRef = useRef<HTMLInputElement>(null);
  const bannerRef = useRef<HTMLInputElement>(null);

  if (!currentUser || currentUser.role !== 'artist') {
    return (
      <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '70vh' }}>
        <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🔒</div>
          <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 16 }}>Artist Access Only</div>
          <button className="btn-rb" onClick={() => navigate('/')}>Go Home</button>
        </div>
      </div>
    );
  }

  const myWorks = artworks.filter(a => a.artistId === currentUser.id);
  const myOrders = orders.filter(o => myWorks.some(a => a.id === o.artId));
  const revenue = myOrders.reduce((s, o) => s + o.amount, 0);
  const followers = (currentUser.followers || []).length;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { setUploadMsg('File too large (max 5MB)'); return; }
    const reader = new FileReader();
    reader.onload = () => setPreviewImg(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setAvatarPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setBannerPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleAddArtwork = () => {
    if (!form.title || !form.price) { setUploadMsg('Title and price are required.'); return; }
    if (isNaN(+form.price) || +form.price <= 0) { setUploadMsg('Enter a valid price.'); return; }
    addArtwork({
      title: form.title,
      description: form.description,
      price: +form.price,
      cat: form.cat,
      artistId: currentUser.id,
      image: previewImg || undefined,
      emoji: '🖼️',
    });
    setForm({ title: '', description: '', price: '', cat: CATS[0] });
    setPreviewImg(null);
    setUploadMsg('✅ Artwork uploaded successfully!');
    setTimeout(() => setUploadMsg(''), 3000);
  };

  const handleSaveProfile = () => {
    updateProfile({ name: editName, bio: editBio, cat: editCat, avatar: avatarPreview || undefined, banner: bannerPreview || undefined });
    setUploadMsg('✅ Profile updated!');
    setTimeout(() => setUploadMsg(''), 3000);
  };

  const handleAddEvent = () => {
    if (!newEventForm.title || !newEventForm.date) { setUploadMsg('Title and date are required'); return; }
    addEvent({
      title: newEventForm.title,
      type: newEventForm.type as any,
      artistId: currentUser.id,
      date: newEventForm.date,
      loc: newEventForm.loc,
      fee: +newEventForm.fee || 0,
      seats: +newEventForm.seats || 0,
      description: newEventForm.description,
      status: 'active',
    });
    setShowNewEvent(false);
    setNewEventForm({ title: '', type: 'workshop', date: '', loc: '', fee: '', seats: '', description: '' });
    setUploadMsg('✅ Event created successfully!');
    setTimeout(() => setUploadMsg(''), 3000);
  };

  const tabStyle = (t: string) => ({ padding: '10px 22px', cursor: 'pointer', fontSize: 13.5, fontWeight: 500, color: activeTab === t ? 'var(--text)' : 'var(--muted)', borderTop: 'none', borderLeft: 'none', borderRight: 'none', borderBottom: `2px solid ${activeTab === t ? '#c77dff' : 'transparent'}`, transition: '.2s', background: 'none', marginBottom: -1, fontFamily: "'DM Sans',sans-serif", whiteSpace: 'nowrap' as const });

  return (
    <div className="page active">
      <div className="con" style={{ paddingTop: 36, paddingBottom: 60 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 32, flexWrap: 'wrap' }}>
          <div style={{ width: 72, height: 72, borderRadius: '50%', background: artGrad(currentUser.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, flexShrink: 0, overflow: 'hidden', border: '3px solid rgba(199,125,255,.4)' }}>
            {currentUser.avatar ? <img src={currentUser.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (currentUser.emoji || currentUser.name[0])}
          </div>
          <div>
            <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900 }}>Artist <span className="rb-text">Dashboard</span></h1>
            <div style={{ fontSize: 13, color: 'var(--muted)' }}>Welcome back, {currentUser.name}</div>
          </div>
        </div>

        {/* KPIs */}
        <div className="kpi-row" style={{ marginBottom: 28 }}>
          {[
            { l: 'Total Revenue', v: fmtInr(revenue), c: '↑ From sales', grad: 'linear-gradient(135deg,#ffd93d,#ff9a3c)' },
            { l: 'Artworks Listed', v: myWorks.length, c: `${myWorks.filter(a => !a.sold).length} available`, grad: 'linear-gradient(135deg,#c77dff,#4d96ff)' },
            { l: 'Total Sales', v: myOrders.length, c: '↑ All time', grad: 'linear-gradient(135deg,#6bcb77,#4d96ff)' },
            { l: 'Followers', v: followers, c: '↑ Growing', grad: 'linear-gradient(135deg,#ff9a3c,#ff6b6b)' },
          ].map(k => (
            <div key={k.l} className="kpi">
              <div className="kpi-l">{k.l}</div>
              <div className="kpi-v" style={{ background: k.grad, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>{k.v}</div>
              <div className="kpi-ch up">{k.c}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: 28, overflowX: 'auto' }}>
          {(['overview', 'upload', 'works', 'posts', 'events', 'notifications', 'profile'] as const).map(t => (
            <button key={t} style={tabStyle(t)} onClick={() => setActiveTab(t)}>
              {t === 'overview' ? '📊 Overview' : t === 'upload' ? '📤 Upload' : t === 'works' ? '🖼 Works' : t === 'posts' ? '📝 Posts' : t === 'events' ? '📅 Events' : t === 'notifications' ? '🔔 Notifications' : '👤 Profile'}
            </button>
          ))}
        </div>

        {uploadMsg && (
          <div style={{ padding: '12px 16px', borderRadius: 10, background: uploadMsg.startsWith('✅') ? 'rgba(107,203,119,.12)' : 'rgba(255,107,107,.12)', border: `1px solid ${uploadMsg.startsWith('✅') ? 'rgba(107,203,119,.3)' : 'rgba(255,107,107,.3)'}`, marginBottom: 20, fontSize: 13, color: uploadMsg.startsWith('✅') ? '#6bcb77' : '#ff6b6b' }}>
            {uploadMsg}
          </div>
        )}

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div>
            <div className="a-tbl">
              <div className="a-th"><div className="a-tt">Recent Sales</div></div>
              <table>
                <thead><tr><th>Artwork</th><th>Amount</th><th>Date</th><th>Status</th></tr></thead>
                <tbody>
                  {myOrders.length === 0
                    ? <tr><td colSpan={4} style={{ textAlign: 'center', color: 'var(--muted)', padding: 20 }}>No sales yet. Upload artworks to start earning!</td></tr>
                    : myOrders.slice().reverse().map(o => {
                        const art = artworks.find(a => a.id === o.artId);
                        return (
                          <tr key={o.id}>
                            <td>{art?.title || 'Unknown'}</td>
                            <td>{fmtInr(o.amount)}</td>
                            <td>{new Date(o.date).toLocaleDateString('en-IN')}</td>
                            <td><span className="pill p-ok">{o.status}</span></td>
                          </tr>
                        );
                      })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Upload Tab */}
        {activeTab === 'upload' && (
          <div style={{ maxWidth: 600 }}>
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, marginBottom: 24 }}>Upload New Artwork</h3>
            {/* Image Upload Area */}
            <div
              style={{ border: '2px dashed rgba(199,125,255,.4)', borderRadius: 16, padding: 30, textAlign: 'center', marginBottom: 20, cursor: 'pointer', background: previewImg ? 'transparent' : 'rgba(199,125,255,.04)', transition: '.3s', position: 'relative', overflow: 'hidden', minHeight: 200 }}
              onClick={() => fileRef.current?.click()}
            >
              {previewImg ? (
                <>
                  <img src={previewImg} alt="preview" style={{ maxWidth: '100%', maxHeight: 260, borderRadius: 12, objectFit: 'contain' }} />
                  <button
                    style={{ position: 'absolute', top: 10, right: 10, background: 'rgba(255,107,107,.8)', border: 'none', borderRadius: '50%', width: 28, height: 28, color: '#fff', cursor: 'pointer', fontSize: 13 }}
                    onClick={e => { e.stopPropagation(); setPreviewImg(null); }}
                  >✕</button>
                </>
              ) : (
                <>
                  <div style={{ fontSize: 48, marginBottom: 12 }}>📸</div>
                  <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6 }}>Click to upload artwork photo</div>
                  <div style={{ fontSize: 12, color: 'var(--muted)' }}>PNG, JPG, WEBP • Max 5MB</div>
                </>
              )}
              <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleImageUpload} />
            </div>
            <div className="fg-m">
              <label>Artwork Title *</label>
              <input type="text" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="e.g. Neon Dreamscape" />
            </div>
            <div className="fg-m">
              <label>Description</label>
              <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Describe your artwork…" />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div className="fg-m">
                <label>Price (₹) *</label>
                <input type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="e.g. 5000" min={1} />
              </div>
              <div className="fg-m">
                <label>Category</label>
                <select value={form.cat} onChange={e => setForm(f => ({ ...f, cat: e.target.value }))}>
                  {CATS.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <button className="sub-btn" onClick={handleAddArtwork}>Upload Artwork 🚀</button>
          </div>
        )}

        {/* My Works Tab */}
        {activeTab === 'works' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
              <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 20 }}>My Artworks ({myWorks.length})</h3>
              <button className="btn-rb" style={{ padding: '9px 18px', fontSize: 13 }} onClick={() => setActiveTab('upload')}>+ Add New</button>
            </div>
            {myWorks.length === 0 ? (
              <div style={{ textAlign: 'center', padding: 60, color: 'var(--muted)' }}>
                <div style={{ fontSize: 48, marginBottom: 12 }}>🖼️</div>
                <div style={{ fontSize: 15, fontWeight: 600 }}>No artworks yet</div>
                <button className="btn-rb" style={{ marginTop: 16 }} onClick={() => setActiveTab('upload')}>Upload First Artwork</button>
              </div>
            ) : (
              <div className="a-tbl">
                <table>
                  <thead><tr><th>Image</th><th>Title</th><th>Category</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
                  <tbody>
                    {myWorks.map(art => (
                      <tr key={art.id}>
                        <td>
                          <div style={{ width: 48, height: 48, borderRadius: 8, overflow: 'hidden', background: artGrad(art.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>
                            {art.image ? <img src={art.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (art.emoji || '🖼️')}
                          </div>
                        </td>
                        <td style={{ fontWeight: 600 }}>{art.title}</td>
                        <td>{art.cat}</td>
                        <td>{fmtInr(art.price)}</td>
                        <td><span className={`pill ${art.sold ? 'p-bad' : 'p-ok'}`}>{art.sold ? 'Sold' : 'Available'}</span></td>
                        <td>
                          <button className="a-btn a-btn-bad" onClick={() => removeArtwork(art.id)}>Remove</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div>
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, marginBottom: 20 }}>Notifications</h3>
            {notifications.filter(n => n.userId === currentUser.id).length === 0 ? (
              <div style={{ textAlign: 'center', padding: 60, color: 'var(--muted)' }}>
                <div style={{ fontSize: 48, marginBottom: 12 }}>🔔</div>
                <div>No notifications yet</div>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {notifications.filter(n => n.userId === currentUser.id).map(n => (
                  <div 
                    key={n.id} 
                    style={{ background: 'var(--card)', borderRadius: 12, border: '1px solid var(--border)', padding: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', opacity: n.read ? 0.7 : 1 }}
                    onClick={() => markNotifRead(n.id)}
                  >
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{n.title}</div>
                      <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>{n.message}</div>
                      <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 8 }}>{new Date(n.at).toLocaleString()}</div>
                    </div>
                    {!n.read && <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#c77dff' }}></div>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Posts Tab */}
        {activeTab === 'posts' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 22 }}>Manage Posts & Achievements</h3>
            </div>
            
            {/* Create Post Form */}
            <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 24, marginBottom: 28 }}>
              <h4 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>New Post</h4>
              <form onSubmit={e => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                addPost({
                  artistId: currentUser.id,
                  title: fd.get('title') as string,
                  text: fd.get('text') as string,
                  tag: fd.get('tag') as 'achievement' | 'post'
                });
                (e.target as HTMLFormElement).reset();
              }}>
                <div className="fg-m"><label>Title</label><input name="title" required placeholder="e.g. My first NFT sold!" /></div>
                <div className="fg-m">
                  <label>Type</label>
                  <select name="tag" className="sort-sel" style={{ width: '100%', padding: '10px 14px', background: 'var(--bg3)', color: 'var(--text)', border: '1px solid var(--border)', borderRadius: 10 }}>
                    <option value="achievement">Achievement 🏆</option>
                    <option value="post">General Update 📝</option>
                  </select>
                </div>
                <div className="fg-m"><label>Message</label><textarea name="text" required placeholder="Share the news with your followers..." style={{ minHeight: 100 }} /></div>
                <button className="sub-btn" type="submit" style={{ maxWidth: 180 }}>Share Post →</button>
              </form>
            </div>

            {/* Post List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {posts.filter(p => p.artistId === currentUser.id).length === 0 ? (
                <div style={{ textAlign: 'center', padding: 40, color: 'var(--muted)', background: 'rgba(255,255,255,.02)', borderRadius: 12 }}>No posts yet. Start sharing your journey!</div>
              ) : (
                [...posts].reverse().filter(p => p.artistId === currentUser.id).map(p => (
                  <div key={p.id} style={{ background: 'var(--card)', borderRadius: 12, border: '1px solid var(--border)', padding: 18 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                      <h4 style={{ fontSize: 16, fontWeight: 700 }}>{p.title}</h4>
                      <span style={{ fontSize: 10, padding: '3px 8px', borderRadius: 8, background: p.tag === 'achievement' ? 'rgba(245,197,24,.15)' : 'rgba(199,125,255,.15)', color: p.tag === 'achievement' ? '#f5c518' : '#c77dff', fontWeight: 700, textTransform: 'uppercase' }}>{p.tag}</span>
                    </div>
                    <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.6 }}>{p.text}</p>
                    <div style={{ marginTop: 12, fontSize: 11, color: 'var(--muted)', display: 'flex', gap: 12 }}>
                      <span>📅 {new Date(p.createdAt).toLocaleDateString()}</span>
                      <span>❤️ {p.likes} likes</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Events Tab */}
        {activeTab === 'events' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
              <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, marginBottom: 0 }}>My Events & Registrations</h3>
              <button className="btn-rb" style={{ padding: '9px 18px', fontSize: 13 }} onClick={() => setShowNewEvent(true)}>+ New Event</button>
            </div>

            {/* New Event Form */}
            {showNewEvent && (
              <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 24, marginBottom: 24 }}>
                <h4 style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, marginBottom: 18 }}>Create New Event</h4>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                  <div className="fg-m"><label>Title *</label><input type="text" value={newEventForm.title} onChange={e => setNewEventForm(f => ({ ...f, title: e.target.value }))} placeholder="e.g. Masterclass" /></div>
                  <div className="fg-m">
                    <label>Type</label>
                    <select value={newEventForm.type} onChange={e => setNewEventForm(f => ({ ...f, type: e.target.value }))}>
                      <option value="workshop">Workshop</option>
                      <option value="exhibition">Exhibition</option>
                      <option value="online">Online</option>
                    </select>
                  </div>
                  <div className="fg-m"><label>Date *</label><input type="date" value={newEventForm.date} onChange={e => setNewEventForm(f => ({ ...f, date: e.target.value }))} /></div>
                  <div className="fg-m"><label>Location</label><input type="text" value={newEventForm.loc} onChange={e => setNewEventForm(f => ({ ...f, loc: e.target.value }))} placeholder="City or Online" /></div>
                  <div className="fg-m"><label>Fee (₹, 0 = Free)</label><input type="number" value={newEventForm.fee} onChange={e => setNewEventForm(f => ({ ...f, fee: e.target.value }))} /></div>
                  <div className="fg-m"><label>Max Seats (0 = Unlimited)</label><input type="number" value={newEventForm.seats} onChange={e => setNewEventForm(f => ({ ...f, seats: e.target.value }))} /></div>
                </div>
                <div className="fg-m"><label>Description</label><textarea value={newEventForm.description} onChange={e => setNewEventForm(f => ({ ...f, description: e.target.value }))} placeholder="Event details…" /></div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button className="sub-btn" style={{ maxWidth: 180 }} onClick={handleAddEvent}>Create Event</button>
                  <button className="t-dl" onClick={() => setShowNewEvent(false)}>Cancel</button>
                </div>
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              {events.filter(e => e.artistId === currentUser.id).length === 0 ? (
                <div style={{ textAlign: 'center', padding: 60, color: 'var(--muted)', background: 'var(--card)', borderRadius: 16 }}>No events found. Contact admin to host an event!</div>
              ) : (
                events.filter(e => e.artistId === currentUser.id).map(ev => (
                  <div key={ev.id} style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 24 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                      <div>
                        <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>{ev.title}</div>
                        <div style={{ fontSize: 13, color: 'var(--muted)' }}>📅 {new Date(ev.date).toLocaleDateString()} · 📍 {ev.loc}</div>
                      </div>
                      <span className="pill p-ok">{ev.status}</span>
                    </div>

                    <div style={{ borderTop: '1px solid var(--border)', paddingTop: 16 }}>
                      <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>Registrations ({(ev.regs || []).length})</div>
                      {(ev.regs || []).length === 0 ? (
                        <div style={{ fontSize: 13, color: 'var(--muted)' }}>No registrations yet.</div>
                      ) : (
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                          <thead>
                            <tr style={{ textAlign: 'left', borderBottom: '1px solid var(--border)' }}>
                              <th style={{ padding: '8px 0', fontSize: 12, color: 'var(--muted)' }}>Attendee</th>
                              <th style={{ padding: '8px 0', fontSize: 12, color: 'var(--muted)' }}>Role</th>
                              <th style={{ padding: '8px 0', fontSize: 12, color: 'var(--muted)' }}>Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(ev.regs || []).map(reg => {
                              const user = users.find(u => u.id === reg.userId);
                              return (
                                <tr key={reg.userId} style={{ borderBottom: '1px solid var(--border)' }}>
                                  <td style={{ padding: '12px 0', fontSize: 13, fontWeight: 600 }}>{user?.name || 'Unknown'}</td>
                                  <td style={{ padding: '12px 0', fontSize: 12 }}><span className="pill p-ok" style={{ fontSize: 10 }}>{user?.role}</span></td>
                                  <td style={{ padding: '12px 0', fontSize: 12, color: 'var(--muted)' }}>{new Date(reg.at).toLocaleDateString()}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Edit Profile Tab */}
        {activeTab === 'profile' && (
          <div style={{ maxWidth: 560 }}>
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, marginBottom: 24 }}>Edit Profile</h3>
            {/* Avatar Upload */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 24 }}>
              <div
                style={{ width: 90, height: 90, borderRadius: '50%', background: artGrad(currentUser.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, cursor: 'pointer', overflow: 'hidden', border: '3px solid rgba(199,125,255,.4)', flexShrink: 0, position: 'relative' }}
                onClick={() => avatarRef.current?.click()}
                title="Click to change avatar"
              >
                {avatarPreview ? <img src={avatarPreview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (currentUser.emoji || currentUser.name[0])}
                <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0, transition: '.2s' }} className="av-hover">📸</div>
              </div>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 4 }}>Profile Photo</div>
                <button className="a-btn a-btn-view" onClick={() => avatarRef.current?.click()}>Upload Photo</button>
                {avatarPreview && <button className="a-btn a-btn-bad" style={{ marginLeft: 6 }} onClick={() => setAvatarPreview(null)}>Remove</button>}
              </div>
              <input ref={avatarRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleAvatarUpload} />
            </div>
            
            {/* Banner Upload */}
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 8 }}>Profile Banner</div>
              <div 
                style={{ width: '100%', height: 120, borderRadius: 12, background: bannerPreview ? 'none' : artGrad(currentUser.id), border: '2px dashed var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', overflow: 'hidden', position: 'relative' }}
                onClick={() => bannerRef.current?.click()}
              >
                {bannerPreview ? <img src={bannerPreview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ color: 'var(--muted)', fontSize: 13 }}>Click to upload banner</span>}
              </div>
              <div style={{ marginTop: 10 }}>
                <button className="a-btn a-btn-view" onClick={() => bannerRef.current?.click()}>Change Banner</button>
                {bannerPreview && <button className="a-btn a-btn-bad" style={{ marginLeft: 6 }} onClick={() => setBannerPreview(null)}>Remove</button>}
              </div>
              <input ref={bannerRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleBannerUpload} />
            </div>

            <div className="fg-m"><label>Display Name</label><input type="text" value={editName} onChange={e => setEditName(e.target.value)} /></div>
            <div className="fg-m"><label>Bio</label><textarea value={editBio} onChange={e => setEditBio(e.target.value)} placeholder="Tell the world about yourself…" /></div>
            <div className="fg-m">
              <label>Art Category</label>
              <select value={editCat} onChange={e => setEditCat(e.target.value)}>{CATS.map(c => <option key={c}>{c}</option>)}</select>
            </div>
            <button className="sub-btn" style={{ maxWidth: 200 }} onClick={handleSaveProfile}>Save Changes ✓</button>
          </div>
        )}
      </div>
    </div>
  );
};
