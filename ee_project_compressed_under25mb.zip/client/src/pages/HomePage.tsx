import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { ArtCard } from '../components/ArtCard';
import { EventCard } from '../components/EventCard';
import type { Event } from '../types';

const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

interface HomePageProps {
  onAuthOpen: (mode: 'login' | 'register') => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onAuthOpen }) => {
  const { artworks, users, events, registerEvent, currentUser } = useStore();
  const navigate = useNavigate();
  const [activeCat, setActiveCat] = useState('All');

  const approvedArtworks = artworks.filter(a => {
    const artist = users.find(u => u.id === a.artistId);
    return a.status === 'approved' && !artist?.banned;
  });
  const categories = ['All', ...Array.from(new Set(approvedArtworks.map(a => a.cat)))];
  const featured = approvedArtworks.filter(a => activeCat === 'All' ? a.featured : a.cat === activeCat).slice(0, 8);
  const artists = users.filter(u => u.role === 'artist' && !u.banned).slice(0, 6);
  const upcomingEvents = events.filter(e => {
    const artist = users.find(u => u.id === e.artistId);
    return e.status === 'active' && e.type !== 'announcement' && (!artist || !artist.banned);
  }).slice(0, 3);
  const announcements = events.filter(e => {
    const artist = users.find(u => u.id === e.artistId);
    return e.status === 'active' && e.type === 'announcement' && (!artist || !artist.banned);
  }).slice(0, 2);

  const handleRegister = (ev: Event) => {
    if (!currentUser) { onAuthOpen('login'); return; }
    const result = registerEvent(ev.id);
    if (result.success) {
      // Show toast
    }
  };

  return (
    <div id="pg-home" className="page active">
      {/* HERO */}
      <section className="hero">
        <div className="hero-orb hero-orb1"></div>
        <div className="hero-orb hero-orb2"></div>
        <div className="hero-orb hero-orb3"></div>
        <div className="hero-grid"></div>
        <div className="hero-content">
          <div className="hero-badge">✦ World's Premium Art Marketplace</div>
          <h1>Where Art Finds<br />Its <span className="rb-text">True Collector</span></h1>
          <p>Discover, collect, and celebrate extraordinary art from independent artists worldwide. Every piece tells a story worth owning.</p>
          <div className="hero-btns">
            <button className="btn-rb" onClick={() => navigate('/shop')}>Explore Art ✦</button>
          </div>
        </div>
      </section>
      
      {/* ANNOUNCEMENTS */}
      {announcements.length > 0 && (
        <section style={{ background: 'linear-gradient(90deg, rgba(199,125,255,.05), rgba(77,150,255,.05))', padding: '16px 0', borderBottom: '1px solid var(--border)' }}>
          <div className="con">
            <div style={{ display: 'flex', gap: 20, overflowX: 'auto', paddingBottom: 4 }}>
              {announcements.map(ann => (
                <div key={ann.id} style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: '300px', flexShrink: 0 }}>
                  <div style={{ background: 'var(--r1)', color: '#fff', fontSize: 10, padding: '2px 8px', borderRadius: 6, fontWeight: 700, textTransform: 'uppercase' }}>Notice</div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{ann.title}</div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* STATS */}
      <div className="stats-bar">
        <div className="stats-inner">
          <div className="stat-item"><div className="stat-n">{artworks.length}+</div><div className="stat-l">Artworks Listed</div></div>
          <div className="stat-item"><div className="stat-n">{users.filter(u => u.role === 'artist').length}+</div><div className="stat-l">Verified Artists</div></div>
          <div className="stat-item"><div className="stat-n">180+</div><div className="stat-l">Countries</div></div>
          <div className="stat-item"><div className="stat-n">25K+</div><div className="stat-l">Sales Made</div></div>
        </div>
      </div>

      {/* FEATURED ARTWORKS */}
      <section className="sec">
        <div className="con">
          <div className="sec-head">
            <h2 className="sec-title">Featured <span className="rb-text">Artworks</span></h2>
            <button className="see-all" onClick={() => navigate('/shop')}>View All →</button>
          </div>
          <div className="cat-pills">
            {categories.map(c => (
              <button key={c} className={`cpill ${activeCat === c ? 'on' : ''}`} onClick={() => setActiveCat(c)}>{c}</button>
            ))}
          </div>
          <div className="art-grid">
            {featured.map(art => (
              <ArtCard
                key={art.id}
                art={art}
                artist={users.find(u => u.id === art.artistId)}
                onArtistClick={id => navigate(`/artists/${id}`)}
                onCardClick={art => navigate(`/artwork/${art.id}`)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* TRENDING ARTISTS */}
      <section className="sec" style={{ background: 'var(--bg2)', padding: '56px 0' }}>
        <div className="con">
          <div className="sec-head">
            <h2 className="sec-title">Trending <span className="rb-text">Artists</span></h2>
            <button className="see-all" onClick={() => navigate('/artists')}>See All →</button>
          </div>
          <div className="a-strip">
            {artists.map(artist => (
              <div key={artist.id} className="asc" onClick={() => navigate(`/artists/${artist.id}`)}>
                <div className="asc-av" style={{ background: artGrad(artist.id) }}>
                  {artist.avatar
                    ? <img src={artist.avatar} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                    : <span style={{ fontSize: 22 }}>{artist.emoji || artist.name[0]}</span>}
                </div>
                <div className="asc-name">{artist.name}</div>
                <div className="asc-type">{artist.cat || 'Artist'}</div>
                <div className="asc-fol">{(artist.followers || []).length} followers</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* UPCOMING EVENTS */}
      <section className="sec" style={{ background: 'var(--bg3)' }}>
        <div className="con">
          <div className="sec-head">
            <h2 className="sec-title">Upcoming <span className="rb-text">Events</span></h2>
            <button className="see-all" onClick={() => navigate('/events')}>View All →</button>
          </div>
          <div className="ann-grid">
            {upcomingEvents.map(ev => (
              <EventCard key={ev.id} event={ev} onRegister={handleRegister} />
            ))}
          </div>
        </div>
      </section>


    </div>
  );
};
