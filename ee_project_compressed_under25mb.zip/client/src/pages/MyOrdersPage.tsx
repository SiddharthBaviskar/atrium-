import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';

const fmtInr = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const fmtDate = (s: string) => new Date(s).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

export const MyOrdersPage: React.FC = () => {
  const { currentUser, orders, artworks, users } = useStore();
  const navigate = useNavigate();

  if (!currentUser) {
    return (
      <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '70vh' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🔒</div>
          <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 16 }}>Please sign in to view your orders</div>
          <button className="btn-rb" onClick={() => navigate('/')}>Go Home</button>
        </div>
      </div>
    );
  }

  const myOrders = orders.filter(o => o.buyerId === currentUser.id).slice().reverse();

  return (
    <div className="page active">
      <div className="con" style={{ paddingTop: 36, paddingBottom: 60 }}>
        <div style={{ marginBottom: 28 }}>
          <h2 className="sec-title">My <span className="rb-text">Orders</span></h2>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 4 }}>{myOrders.length} purchase{myOrders.length !== 1 ? 's' : ''} made</p>
        </div>

        {myOrders.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '80px 20px', color: 'var(--muted)' }}>
            <div style={{ fontSize: 56, marginBottom: 16 }}>📦</div>
            <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>No orders yet</div>
            <div style={{ fontSize: 13, marginBottom: 24 }}>Start collecting art from our marketplace</div>
            <button className="btn-rb" onClick={() => navigate('/shop')}>Browse Artworks →</button>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {myOrders.map(order => {
              const art = artworks.find(a => a.id === order.artId);
              const artist = art ? users.find(u => u.id === art.artistId) : undefined;
              return (
                <div key={order.id} style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 20, display: 'flex', gap: 18, alignItems: 'center', flexWrap: 'wrap' }}>
                  <div style={{ width: 72, height: 72, borderRadius: 12, background: art ? artGrad(art.id) : 'var(--bg3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, flexShrink: 0, overflow: 'hidden' }}>
                    {art?.image
                      ? <img src={art.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      : (art?.emoji || '🖼️')}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 17, fontWeight: 700, marginBottom: 3 }}>{art?.title || 'Unknown Artwork'}</div>
                    <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 4 }}>by {artist?.name || 'Unknown Artist'}</div>
                    <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>Order ID: <span style={{ fontFamily: 'monospace' }}>{order.id}</span> · {fmtDate(order.date)}</div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontSize: 20, fontWeight: 700, background: 'linear-gradient(135deg,#f5c518,#ff9a3c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>{fmtInr(order.amount)}</div>
                    <span className="pill p-ok" style={{ marginTop: 6 }}>{order.status}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
