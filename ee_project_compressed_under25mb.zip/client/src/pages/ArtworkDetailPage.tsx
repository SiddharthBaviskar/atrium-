import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';

const fmtInr = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

interface ArtworkDetailPageProps {
  onAuthOpen: (mode: 'login' | 'register') => void;
}

export const ArtworkDetailPage: React.FC<ArtworkDetailPageProps> = ({ onAuthOpen }) => {
  const { id } = useParams<{ id: string }>();
  const { artworks, users, addToCart, toggleWishlist, wishlist, currentUser, addReport } = useStore();
  const navigate = useNavigate();
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState('Inappropriate content');
  const [reportDesc, setReportDesc] = useState('');
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  const art = artworks.find(a => a.id === id);
  const artist = art ? users.find(u => u.id === art.artistId) : undefined;
  
  if (artist?.banned && currentUser?.role !== 'admin') {
    return (
      <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '70vh' }}>
        <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🚫</div>
          <div style={{ fontSize: 18, fontWeight: 600 }}>The artist is currently unavailable</div>
          <div style={{ fontSize: 14, marginTop: 8 }}>This artwork cannot be purchased.</div>
          <button className="btn-rb" style={{ marginTop: 20 }} onClick={() => navigate('/shop')}>Back to Shop</button>
        </div>
      </div>
    );
  }

  if (!art || (art.status !== 'approved' && currentUser?.role !== 'admin')) {
    return (
      <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '70vh' }}>
        <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🔍</div>
          <div style={{ fontSize: 18, fontWeight: 600 }}>Artwork not found</div>
          <button className="btn-rb" style={{ marginTop: 20 }} onClick={() => navigate('/shop')}>Back to Shop</button>
        </div>
      </div>
    );
  }

  const related = artworks.filter(a => {
    if (a.id === art.id || a.cat !== art.cat || a.status !== 'approved') return false;
    const aArtist = users.find(u => u.id === a.artistId);
    return !aArtist?.banned;
  }).slice(0, 4);
  const isWished = wishlist.includes(art.id);

  const handleAddToCart = () => {
    if (!currentUser) { onAuthOpen('login'); return; }
    addToCart(art.id);
  };

  const handleWishlist = () => {
    if (!currentUser) { onAuthOpen('login'); return; }
    toggleWishlist(art.id);
  };

  const handleReport = () => {
    if (!currentUser) return;
    if (!reportDesc.trim()) { showToast('Please add a description'); return; }
    addReport({
      reporterId: currentUser.id,
      targetType: 'artwork',
      targetId: art.id,
      reason: reportReason,
      description: reportDesc
    });
    setShowReport(false);
    setReportDesc('');
    showToast('Artwork reported. Admin will review.');
  };

  return (
    <div className="page active">
      {toast && (
        <div style={{ position: 'fixed', bottom: 22, right: 22, zIndex: 9500, padding: '13px 18px', borderRadius: 13, background: 'var(--card)', border: '1px solid rgba(107,203,119,.4)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 9, boxShadow: 'var(--shadow)' }}>
          ✅ {toast}
        </div>
      )}
      <div className="con" style={{ paddingTop: 36, paddingBottom: 60 }}>
        <button className="nb ghost" style={{ marginBottom: 24 }} onClick={() => navigate(-1)}>← Back</button>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'start' }}>
          {/* Left: Image */}
          <div>
            <div style={{ borderRadius: 20, overflow: 'hidden', background: artGrad(art.id), aspectRatio: '4/3', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid var(--border)', position: 'relative' }}>
              {art.image
                ? <img src={art.image} alt={art.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : <span style={{ fontSize: 100 }}>{art.emoji || '🖼️'}</span>}
              {art.sold && (
                <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.6)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <span style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 48, color: '#fff', letterSpacing: 3, opacity: 0.9 }}>SOLD</span>
                </div>
              )}
            </div>
            <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
              <button
                style={{ flex: 1, padding: '10px 0', borderRadius: 12, border: `1px solid ${isWished ? 'var(--r1)' : 'var(--border)'}`, background: isWished ? 'rgba(255,107,107,.1)' : 'transparent', color: isWished ? '#ff6b6b' : 'var(--muted)', cursor: 'pointer', fontSize: 13, fontFamily: "'DM Sans',sans-serif", transition: '.25s' }}
                onClick={handleWishlist}
              >
                {isWished ? '❤️ Wishlisted' : '🤍 Add to Wishlist'}
              </button>
              <button style={{ flex: 1, padding: '10px 0', borderRadius: 12, border: '1px solid var(--border)', background: 'transparent', color: 'var(--muted)', cursor: 'pointer', fontSize: 13, fontFamily: "'DM Sans',sans-serif" }}
                onClick={() => { navigator.clipboard?.writeText(window.location.href); }}>
                🔗 Share
              </button>
              <button style={{ flex: 1, padding: '10px 0', borderRadius: 12, border: '1px solid var(--border)', background: 'transparent', color: 'var(--muted)', cursor: 'pointer', fontSize: 13, fontFamily: "'DM Sans',sans-serif" }}
                onClick={() => { if(!currentUser) onAuthOpen('login'); else setShowReport(true); }}>
                🚩 Report
              </button>
            </div>
            
            {showReport && (
              <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 20, marginTop: 20 }}>
                <h4 style={{ fontSize: 15, marginBottom: 14 }}>Report this Artwork</h4>
                <div className="fg-m">
                  <label>Reason</label>
                  <select value={reportReason} onChange={e => setReportReason(e.target.value)}>
                    <option value="Inappropriate content">Inappropriate content</option>
                    <option value="Copyright violation">Copyright violation</option>
                    <option value="Spam / Scam">Spam / Scam</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div className="fg-m">
                  <label>Description</label>
                  <textarea value={reportDesc} onChange={e => setReportDesc(e.target.value)} placeholder="Provide details..." rows={3} />
                </div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button className="sub-btn" onClick={handleReport}>Submit Report</button>
                  <button className="t-dl" onClick={() => setShowReport(false)}>Cancel</button>
                </div>
              </div>
            )}
          </div>

          {/* Right: Info */}
          <div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
              <span className="ab ab-new" style={{ position: 'static' }}>{art.cat}</span>
              {art.featured && <span className="ab ab-hot" style={{ position: 'static' }}>Featured</span>}
              {art.sold && <span className="ab ab-sold" style={{ position: 'static' }}>Sold</span>}
            </div>
            <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(26px,4vw,40px)', fontWeight: 900, lineHeight: 1.15, marginBottom: 14 }}>{art.title}</h1>
            {artist && (
              <div className="art-by" style={{ marginBottom: 18, fontSize: 14 }} onClick={() => navigate(`/artists/${artist.id}`)}>
                <div style={{ width: 36, height: 36, borderRadius: '50%', background: artGrad(artist.id), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, overflow: 'hidden', flexShrink: 0 }}>
                  {artist.avatar ? <img src={artist.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (artist.emoji || artist.name[0])}
                </div>
                <div>
                  <div style={{ fontWeight: 600, color: 'var(--text)' }}>{artist.name}</div>
                  <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>{artist.cat || 'Artist'} · {(artist.followers || []).length} followers</div>
                </div>
              </div>
            )}
            {art.description && (
              <p style={{ fontSize: 14.5, color: 'var(--muted)', lineHeight: 1.75, marginBottom: 28 }}>{art.description}</p>
            )}

            {/* Price + CTA */}
            <div style={{ background: 'var(--card)', borderRadius: 16, border: '1px solid var(--border)', padding: 22, marginBottom: 20 }}>
              <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', marginBottom: 6 }}>Price</div>
              <div className="art-price" style={{ fontSize: 32, marginBottom: 18 }}>{fmtInr(art.price)}</div>
              {!art.sold ? (
                <button className="sub-btn" onClick={handleAddToCart}>🛒 Add to Cart</button>
              ) : (
                <div style={{ padding: 14, borderRadius: 12, background: 'var(--bg3)', textAlign: 'center', color: 'var(--muted)', fontSize: 14 }}>This artwork has been sold</div>
              )}
            </div>

            {/* Details */}
            <div style={{ background: 'var(--card)', borderRadius: 14, border: '1px solid var(--border)', padding: 18 }}>
              <div style={{ fontSize: 12.5, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', marginBottom: 12 }}>Details</div>
              {[
                { label: 'Category', value: art.cat },
                { label: 'Artist', value: artist?.name || 'Unknown' },
                { label: 'Listed', value: art.createdAt ? new Date(art.createdAt).toLocaleDateString('en-IN') : '—' },
                { label: 'Status', value: art.sold ? 'Sold' : 'Available' },
              ].map(d => (
                <div key={d.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                  <span style={{ color: 'var(--muted)' }}>{d.label}</span>
                  <span style={{ fontWeight: 500 }}>{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Related Works */}
        {related.length > 0 && (
          <div style={{ marginTop: 60 }}>
            <h2 className="sec-title" style={{ marginBottom: 24 }}>More in <span className="rb-text">{art.cat}</span></h2>
            <div className="art-grid">
              {related.map(r => {
                const a = users.find(u => u.id === r.artistId);
                return (
                  <div key={r.id} className="art-card" onClick={() => navigate(`/artwork/${r.id}`)}>
                    <div className="art-thumb" style={{ background: artGrad(r.id) }}>
                      {r.image ? <img src={r.image} alt={r.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ fontSize: 62 }}>{r.emoji || '🖼️'}</span>}
                      {r.sold && <span className="ab ab-sold">Sold</span>}
                    </div>
                    <div className="art-info">
                      <div className="art-title">{r.title}</div>
                      <div className="art-by">{a?.name}</div>
                      <div className="art-foot">
                        <div className="art-price">{fmtInr(r.price)}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
