import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useStore } from './store/useStore';
import { Navbar } from './components/Navbar';
import { CartSidebar } from './components/CartSidebar';
import { AuthModal } from './components/AuthModal';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ArtistsPage } from './pages/ArtistsPage';
import { ArtistProfilePage } from './pages/ArtistProfilePage';
import { ArtworkDetailPage } from './pages/ArtworkDetailPage';
import { EventsPage } from './pages/EventsPage';
import { MessagesPage } from './pages/MessagesPage';
import { ArtistDashboard } from './pages/ArtistDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { AccountPage } from './pages/AccountPage';
import { MyOrdersPage } from './pages/MyOrdersPage';
import { NotificationsPage } from './pages/NotificationsPage';
import './App.css';

function App() {
  const { cart, theme } = useStore();
  const [cartOpen, setCartOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Sync theme on mount
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const openAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setAuthOpen(true);
  };

  return (
    <BrowserRouter>
      <Navbar
        onCartOpen={() => setCartOpen(true)}
        cartCount={cart.length}
        onAuthOpen={openAuth}
      />
      <CartSidebar open={cartOpen} onClose={() => setCartOpen(false)} />
      <AuthModal
        open={authOpen}
        mode={authMode}
        onClose={() => setAuthOpen(false)}
        onSwitch={m => setAuthMode(m)}
      />
      {/* Toast container */}
      <div className="toast-wrap" id="toastWrap"></div>

      <Routes>
        <Route path="/" element={<HomePage onAuthOpen={openAuth} />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/artists" element={<ArtistsPage onAuthOpen={openAuth} />} />
        <Route path="/artists/:id" element={<ArtistProfilePage onAuthOpen={openAuth} />} />
        <Route path="/artwork/:id" element={<ArtworkDetailPage onAuthOpen={openAuth} />} />
        <Route path="/events" element={<EventsPage />} />
        <Route path="/messages" element={<MessagesPage />} />
        <Route path="/artist-dashboard" element={<ArtistDashboard />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/account" element={<AccountPage />} />
        <Route path="/my-orders" element={<MyOrdersPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="*" element={
          <div className="page active" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '70vh' }}>
            <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
              <div style={{ fontSize: 64, marginBottom: 16 }}>404</div>
              <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, fontWeight: 700, marginBottom: 12 }}>Page Not Found</div>
              <a href="/" className="btn-rb" style={{ display: 'inline-flex', textDecoration: 'none' }}>Go Home</a>
            </div>
          </div>
        } />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}

export default App;
