export type UserRole = 'buyer' | 'artist' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: UserRole;
  bio?: string;
  cat?: string;
  avatar?: string; // base64 or URL
  banner?: string; // base64 or URL
  emoji?: string;
  followers?: string[];
  joinedAt?: string;
  banned?: boolean;
}

export interface Artwork {
  id: string;
  title: string;
  description?: string;
  price: number;
  cat: string;
  artistId: string;
  image?: string; // base64 or URL (replaces emoji)
  emoji?: string; // legacy fallback
  sold?: boolean;
  featured?: boolean;
  createdAt?: string;
  likes?: string[];
  status?: 'pending' | 'approved' | 'rejected'; // Added for moderation flow
}

export interface Order {
  id: string;
  artId: string;
  buyerId: string;
  amount: number;
  date: string;
  status: 'Paid' | 'Pending' | 'Refunded';
}

export interface Event {
  id: string;
  title: string;
  type: 'workshop' | 'exhibition' | 'online' | 'sale' | 'announcement';
  artistId: string;
  date: string;
  loc?: string;
  fee: number;
  seats: number;
  description?: string;
  regs?: EventRegistration[];
  status: 'active' | 'cancelled' | 'pending';
}

export interface EventRegistration {
  userId: string;
  userName: string;
  ticketId: string;
  seat: string;
  at: string;
}

export interface Message {
  id: string;
  fromId: string;
  text: string;
  at: string;
  read: boolean;
}

export type Messages = Record<string, Message[]>;

export interface CartItem {
  artId: string;
  at: string;
}

export interface Post {
  id: string;
  artistId: string;
  title: string;
  text: string;
  tag: 'achievement' | 'post';
  likes: number;
  shares: number;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'sale' | 'message' | 'follower' | 'event' | 'info' | 'warning';
  at: string;
  read: boolean;
  link?: string;
}

export interface Report {
  id: string;
  reporterId: string;
  targetType: 'artist' | 'artwork';
  targetId: string;
  reason: string;
  description: string;
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  createdAt: string;
}
