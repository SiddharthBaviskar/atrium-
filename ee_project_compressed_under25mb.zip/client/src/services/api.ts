import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use((config) => {
  const store = localStorage.getItem('atrium-store');
  if (store) {
    const { state } = JSON.parse(store);
    if (state.currentUser?.token) {
      config.headers.Authorization = `Bearer ${state.currentUser.token}`;
    }
  }
  return config;
});

export default api;
