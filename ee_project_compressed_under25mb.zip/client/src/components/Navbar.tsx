import React, { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import logoImg from '../assets/media__1778860426017.png';

interface NavbarProps {
  onCartOpen: () => void;
  cartCount: number;
  onAuthOpen: (mode: 'login' | 'register') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onCartOpen, cartCount, onAuthOpen }) => {
  const { theme, toggleTheme, currentUser, logout, notifications, markNotifRead, clearNotifications } = useStore();
  const [search, setSearch] = useState('');
  const [dropOpen, setDropOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const navigate = useNavigate();
  const dropRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  const unreadNotifs = currentUser 
    ? notifications.filter(n => n.userId === currentUser.id && !n.read)
    : [];

  const userNotifs = currentUser
    ? notifications.filter(n => n.userId === currentUser.id)
    : [];

  const handleSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && search.trim()) {
      navigate(`/shop?q=${encodeURIComponent(search.trim())}`);
      setSearch('');
    }
  };

  const handleLogout = () => {
    logout();
    setDropOpen(false);
    navigate('/');
  };

  const navLinks = [
    { to: '/shop', label: '🛍 Shop' },
    { to: '/artists', label: '🎨 Artists' },
    { to: '/events', label: '📢 Events' },
  ];

  return (
    <>
      <div className="rb-bar"></div>
      <nav>
        <div className="nav-inner">
          <Link to="/" className="logo-link">
            <img src={logoImg} alt="ATRIUM" className="nav-logo-img" />
          </Link>

          <div className="nav-search">
            <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input
              type="text"
              placeholder="Search art, artists…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={handleSearch}
            />
          </div>

          <div className="nav-links">
            {navLinks.map(l => (
              <Link key={l.to} to={l.to} className="nb ghost">{l.label}</Link>
            ))}
            {currentUser && (
              <Link to="/messages" className="nb ghost">💬 Messages</Link>
            )}
            {currentUser?.role === 'admin' && (
              <Link to="/admin" className="nb ghost">⚙ Admin</Link>
            )}
            {currentUser?.role === 'artist' && (
              <Link to="/artist-dashboard" className="nb ghost">🎨 Dashboard</Link>
            )}

            <div className="cart-wrap">
              <button className="nb out" onClick={onCartOpen}>
                🛒<span className="cart-badge">{cartCount}</span>
              </button>
            </div>

            <div className="theme-pill" onClick={toggleTheme}>
              <div className="theme-track">
                <div className="theme-thumb">{theme === 'dark' ? '🌙' : '☀️'}</div>
              </div>
              <span className="theme-lbl">{theme === 'dark' ? 'Dark' : 'Light'}</span>
            </div>

            <div className="notif-wrap" ref={notifRef}>
              <button 
                className="nb ghost" 
                onClick={() => currentUser ? setNotifOpen(v => !v) : onAuthOpen('login')} 
                style={{ position: 'relative', fontSize: '18px' }}
                title={currentUser ? 'Notifications' : 'Sign in to see notifications'}
              >
                🔔
                {unreadNotifs.length > 0 && (
                  <span className="cart-badge" style={{ top: '-2px', right: '-2px' }}>{unreadNotifs.length}</span>
                )}
              </button>
              {currentUser && (
                <div className={`user-drop ${notifOpen ? 'open' : ''}`} style={{ width: '300px', padding: '0' }}>
                  <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontWeight: 600 }}>Notifications</span>
                    <button onClick={clearNotifications} style={{ background: 'none', border: 'none', color: '#c77dff', fontSize: '11px', cursor: 'pointer' }}>Clear All</button>
                  </div>
                  <div style={{ maxHeight: '360px', overflowY: 'auto' }}>
                    {userNotifs.length === 0 ? (
                      <div style={{ padding: '30px 16px', textAlign: 'center', color: 'var(--muted)', fontSize: '13px' }}>
                        No notifications yet
                      </div>
                    ) : (
                      userNotifs.map(n => (
                        <div 
                          key={n.id} 
                          className={`ud-item ${!n.read ? 'unread' : ''}`} 
                          style={{ padding: '12px 16px', display: 'block', borderBottom: '1px solid var(--border)', background: !n.read ? 'rgba(199,125,255,.05)' : 'transparent' }}
                          onClick={() => {
                            markNotifRead(n.id);
                            if (n.link) navigate(n.link);
                            setNotifOpen(false);
                          }}
                        >
                          <div style={{ fontWeight: 600, fontSize: '13px', marginBottom: '2px' }}>{n.title}</div>
                          <div style={{ fontSize: '12px', color: 'var(--muted)', lineHeight: '1.4' }}>{n.message}</div>
                          <div style={{ fontSize: '10px', color: 'var(--muted)', marginTop: '4px' }}>{new Date(n.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {currentUser ? (
              <div className="user-area" ref={dropRef}>
                <div className="user-av" onClick={() => setDropOpen(v => !v)}>
                  {currentUser.avatar
                    ? <img src={currentUser.avatar} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                    : (currentUser.emoji || currentUser.name[0].toUpperCase())}
                </div>
                <div className={`user-drop ${dropOpen ? 'open' : ''}`}>
                  <div className="ud-name">{currentUser.name}</div>
                  <div className="ud-email">{currentUser.email}</div>
                  <div className="ud-item" onClick={() => { navigate('/account'); setDropOpen(false); }}>
                    <span>👤</span> My Account
                  </div>
                  {currentUser.role === 'artist' && (
                    <div className="ud-item" onClick={() => { navigate(`/artists/${currentUser.id}`); setDropOpen(false); }}>
                      <span>🎨</span> My Profile
                    </div>
                  )}
                  {currentUser.role === 'buyer' && (
                    <div className="ud-item" onClick={() => { navigate('/my-orders'); setDropOpen(false); }}>
                      <span>📦</span> My Orders
                    </div>
                  )}
                  <div className="ud-item danger" onClick={handleLogout}>
                    <span>🚪</span> Sign Out
                  </div>
                </div>
              </div>
            ) : (
              <>
                <button className="nb prim" onClick={() => onAuthOpen('register')}>Join Free</button>
              </>
            )}
          </div>
        </div>
      </nav>
    </>
  );
};
