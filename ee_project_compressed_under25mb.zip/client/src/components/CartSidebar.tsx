import React from 'react';
import { useStore } from '../store/useStore';
import { useNavigate } from 'react-router-dom';

const fmtInr = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const GRAD = ['linear-gradient(135deg,#0a0020,#c77dff33)', 'linear-gradient(135deg,#00081a,#4d96ff33)', 'linear-gradient(135deg,#0d0010,#ff6b6b33)'];
const artGrad = (id: string) => GRAD[id.charCodeAt(0) % GRAD.length];

interface CartSidebarProps {
  open: boolean;
  onClose: () => void;
}

export const CartSidebar: React.FC<CartSidebarProps> = ({ open, onClose }) => {
  const { cart, artworks, users, removeFromCart, checkout, currentUser } = useStore();
  const navigate = useNavigate();

  const cartItems = cart.map(item => {
    const art = artworks.find(a => a.id === item.artId);
    const artist = art ? users.find(u => u.id === art.artistId) : undefined;
    return { item, art, artist };
  }).filter(i => i.art && i.art.status === 'approved' && i.artist && !i.artist.banned);

  const total = cartItems.reduce((s, i) => s + (i.art?.price || 0), 0);

  const handleCheckout = () => {
    const placed = checkout();
    if (placed > 0) {
      onClose();
      navigate('/my-orders');
    }
  };

  return (
    <>
      {open && <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.4)', zIndex: 3999 }} onClick={onClose} />}
      <div className={`cart-side ${open ? 'open' : ''}`}>
        <div className="cart-hd">
          <h3>Your Cart</h3>
          <button className="mcl" style={{ position: 'static', width: 30, height: 30 }} onClick={onClose}>✕</button>
        </div>
        <div className="cart-items" id="cartItems">
          {cartItems.length === 0 ? (
            <div className="cart-empty-state">
              <div style={{ fontSize: 48 }}>🛒</div>
              <div style={{ fontWeight: 600, marginBottom: 8 }}>Cart is empty</div>
              <button className="nb prim" onClick={() => { onClose(); navigate('/shop'); }}>Browse Art</button>
            </div>
          ) : (
            cartItems.map(({ item, art, artist }) => art && (
              <div className="ci" key={item.artId}>
                <div className="ci-thumb" style={{ background: art.image ? 'transparent' : artGrad(art.id) }}>
                  {art.image
                    ? <img src={art.image} alt={art.title} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 8 }} />
                    : <span style={{ fontSize: 24 }}>{art.emoji || '🖼️'}</span>}
                </div>
                <div className="ci-info">
                  <div className="ci-title">{art.title}</div>
                  <div className="ci-artist">{artist?.name || 'Unknown'}</div>
                  <div className="ci-price">{fmtInr(art.price)}</div>
                </div>
                <button className="ci-rm" onClick={() => removeFromCart(item.artId)}>✕</button>
              </div>
            ))
          )}
        </div>
        {cartItems.length > 0 && (
          <div className="cart-ft" id="cartFt">
            <div className="cart-total-row">
              <span>Total</span>
              <span>{fmtInr(total)}</span>
            </div>
            {currentUser ? (
              <button className="checkout-btn" onClick={handleCheckout}>Checkout →</button>
            ) : (
              <button className="checkout-btn" onClick={() => { onClose(); }}>Sign in to Checkout</button>
            )}
          </div>
        )}
      </div>
    </>
  );
};
