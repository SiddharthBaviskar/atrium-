import React from 'react';

export const StatsBar = () => {
  return (
    <div className="stats-bar">
      <div className="stats-inner">
        <div className="stat-item"><div className="stat-n">10K+</div><div className="stat-l">Artworks Listed</div></div>
        <div className="stat-item"><div className="stat-n">5K+</div><div className="stat-l">Verified Artists</div></div>
        <div className="stat-item"><div className="stat-n">180+</div><div className="stat-l">Countries</div></div>
        <div className="stat-item"><div className="stat-n">25K+</div><div className="stat-l">Sales Made</div></div>
      </div>
    </div>
  );
};
