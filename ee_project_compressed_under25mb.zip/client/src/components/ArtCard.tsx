import React from 'react';
import type { Artwork, User } from '../types';
import { useStore } from '../store/useStore';

interface ArtCardProps {
  art: Artwork;
  artist: User | undefined;
  onArtistClick?: (artistId: string) => void;
  onCardClick?: (art: Artwork) => void;
}

const GRADIENTS = [
  'linear-gradient(135deg,#0a0020,#c77dff33)',
  'linear-gradient(135deg,#00081a,#4d96ff33)',
  'linear-gradient(135deg,#0d0010,#ff6b6b33)',
  'linear-gradient(135deg,#001000,#6bcb7733)',
  'linear-gradient(135deg,#100500,#ffd93d33)',
];
const artGrad = (id: string) => GRADIENTS[id.charCodeAt(0) % GRADIENTS.length];

const fmtInr = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

export const ArtCard: React.FC<ArtCardProps> = ({ art, artist, onArtistClick, onCardClick }) => {
  const { addToCart, toggleWishlist, wishlist, currentUser } = useStore();

  const isWished = wishlist.includes(art.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) return;
    addToCart(art.id);
  };

  const handleWish = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) return;
    toggleWishlist(art.id);
  };

  return (
    <div className="art-card" onClick={() => onCardClick?.(art)}>
      <div className="art-thumb" style={{ background: artGrad(art.id) }}>
        {art.image ? (
          <img
            src={art.image}
            alt={art.title}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        ) : (
          <span style={{ fontSize: 62 }}>{art.emoji || '🖼️'}</span>
        )}
        {art.featured && <span className="ab ab-new">Featured</span>}
        {art.sold && <span className="ab ab-sold">Sold</span>}
        {!art.sold && !art.featured && <span className="ab ab-hot">Hot</span>}
        <button
          className={`art-wish ${isWished ? 'liked' : ''}`}
          onClick={handleWish}
          title={isWished ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          {isWished ? '❤️' : '🤍'}
        </button>
      </div>
      <div className="art-info">
        <div className="art-title">{art.title}</div>
        {artist && (
          <div className="art-by" onClick={e => { e.stopPropagation(); onArtistClick?.(artist.id); }}>
            <div className="art-by-av" style={{ background: artGrad(artist.id) }}>
              {artist.avatar
                ? <img src={artist.avatar} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                : (artist.emoji || artist.name[0])}
            </div>
            {artist.name}
          </div>
        )}
        <div className="art-foot">
          <div className="art-price">{fmtInr(art.price)}</div>
          {!art.sold ? (
            <button className="art-add" onClick={handleAddToCart}>
              + Add
            </button>
          ) : (
            <span style={{ fontSize: '11.5px', color: 'var(--muted)' }}>Sold</span>
          )}
        </div>
      </div>
    </div>
  );
};
