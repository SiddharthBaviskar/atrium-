import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store/useStore';
import logoImg from '../assets/media__1778860426017.png';

export const Footer: React.FC = () => {
  const { currentUser, sendMessage } = useStore();
  const [showHelp, setShowHelp] = useState(false);
  const [helpMsg, setHelpMsg] = useState('');
  const [sent, setSent] = useState(false);

  const handleContactAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      alert('Please sign in to contact support.');
      return;
    }
    // Find admin user - in our demo store 'admin' has id 'u2'
    sendMessage('u2', helpMsg);
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setShowHelp(false);
      setHelpMsg('');
    }, 3000);
  };

  return (
    <footer style={{ background: 'var(--bg2)', borderTop: '1px solid var(--border)', padding: '60px 0 40px', marginTop: 80 }}>
      <div className="con">
        <div className="foot-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 40, marginBottom: 40 }}>
          <div className="foot-brand">
            <img src={logoImg} alt="ATRIUM" className="footer-logo-img" />
            <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.6, maxWidth: 280 }}>
              The premier marketplace for digital and physical art. Connecting visionary artists with passionate collectors worldwide.
            </p>
          </div>
          
          <div className="foot-col">
            <h4 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Marketplace</h4>
            <ul className="foot-links" style={{ listStyle: 'none', padding: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
              <li><Link to="/shop" style={{ fontSize: 13, color: 'var(--muted)', textDecoration: 'none' }}>Browse Art</Link></li>
              <li><Link to="/artists" style={{ fontSize: 13, color: 'var(--muted)', textDecoration: 'none' }}>Artists</Link></li>
              <li><Link to="/events" style={{ fontSize: 13, color: 'var(--muted)', textDecoration: 'none' }}>Workshops</Link></li>
            </ul>
          </div>

          <div className="foot-col">
            <h4 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Account</h4>
            <ul className="foot-links" style={{ listStyle: 'none', padding: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
              <li><Link to="/account" style={{ fontSize: 13, color: 'var(--muted)', textDecoration: 'none' }}>My Profile</Link></li>
              <li><Link to="/my-orders" style={{ fontSize: 13, color: 'var(--muted)', textDecoration: 'none' }}>Order History</Link></li>
              <li><Link to="/artist-dashboard" style={{ fontSize: 13, color: 'var(--muted)', textDecoration: 'none' }}>Artist Dashboard</Link></li>
            </ul>
          </div>

          <div className="foot-col">
            <h4 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Help & Support</h4>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 16 }}>Need assistance? Our team is here to help you.</p>
            <button 
              className="nb out" 
              style={{ padding: '8px 20px', borderRadius: 20, cursor: 'pointer' }}
              onClick={() => setShowHelp(true)}
            >
              Contact Support ✉️
            </button>
          </div>
        </div>

        <div style={{ borderTop: '1px solid var(--border)', paddingTop: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 20 }}>
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>© 2026 Atrium Verse. All rights reserved.</div>
          <div style={{ display: 'flex', gap: 20 }}>
            {['Twitter', 'Instagram', 'Discord', 'LinkedIn'].map(s => (
              <a key={s} href="#" style={{ fontSize: 12, color: 'var(--muted)', textDecoration: 'none' }}>{s}</a>
            ))}
          </div>
        </div>
      </div>

      {/* Help Modal */}
      {showHelp && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.7)', backdropFilter: 'blur(8px)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 24, padding: 32, width: '100%', maxWidth: 450, position: 'relative' }}>
            <button style={{ position: 'absolute', top: 20, right: 20, background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: 20 }} onClick={() => setShowHelp(false)}>✕</button>
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, marginBottom: 12 }}>Contact Admin</h3>
            <p style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 24 }}>Describe your issue or question below. An administrator will reply shortly.</p>
            
            {sent ? (
              <div style={{ textAlign: 'center', padding: '40px 0' }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
                <div style={{ fontWeight: 600 }}>Message Sent!</div>
                <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 8 }}>We'll get back to you in your messages.</div>
              </div>
            ) : (
              <form onSubmit={handleContactAdmin}>
                <div className="fg-m">
                  <label>Message</label>
                  <textarea 
                    required 
                    value={helpMsg} 
                    onChange={e => setHelpMsg(e.target.value)}
                    placeholder="How can we help you today?" 
                    style={{ minHeight: 120, background: 'var(--bg3)', color: 'var(--text)', border: '1px solid var(--border)', borderRadius: 12, padding: 14, width: '100%', outline: 'none' }}
                  />
                </div>
                <button className="sub-btn" type="submit">Send Message →</button>
              </form>
            )}
          </div>
        </div>
      )}
    </footer>
  );
};
