import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { useNavigate } from 'react-router-dom';

interface AuthModalProps {
  open: boolean;
  mode: 'login' | 'register';
  onClose: () => void;
  onSwitch: (mode: 'login' | 'register') => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ open, mode, onClose, onSwitch }) => {
  const { login, register } = useStore();
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'buyer' | 'artist'>('buyer');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!open) return null;

  const handleLogin = async () => {
    if (!email || !password) { setError('Please fill all fields.'); return; }
    setLoading(true);
    const result = login(email.trim(), password);
    setLoading(false);
    if (result.success) {
      onClose();
      setEmail(''); setPassword(''); setError('');
    } else {
      setError(result.message);
    }
  };

  const handleRegister = async () => {
    if (!name || !email || !password) { setError('Please fill all fields.'); return; }
    if (password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    setLoading(true);
    const result = register(name.trim(), email.trim(), password, role);
    setLoading(false);
    if (result.success) {
      onClose();
      setName(''); setEmail(''); setPassword(''); setError('');
      if (role === 'artist') navigate(`/artist-dashboard`);
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="overlay open" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <button className="mcl" onClick={onClose}>✕</button>
        <div className="modal-in">
          <span className="m-logo">ATRIUM</span>

          {mode === 'login' ? (
            <>
              <h2>Welcome back</h2>
              <p className="sub">Sign in to your Atrium account</p>
              <div className="demo-hint">
                <strong>Demo accounts:</strong><br/>
                Artist: priya@art.com / priya123<br/>
                Admin: admin@atrium.com / admin123<br/>
                Buyer: anjali@email.com / anjali123
              </div>
              <div className="fg-m">
                <label>Email Address</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" onKeyDown={e => e.key === 'Enter' && handleLogin()} />
              </div>
              <div className="fg-m">
                <label>Password</label>
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" onKeyDown={e => e.key === 'Enter' && handleLogin()} />
              </div>
              {error && <div style={{ color: 'var(--r1)', fontSize: 12, marginBottom: 12 }}>{error}</div>}
              <button className="sub-btn" onClick={handleLogin} disabled={loading}>
                {loading ? 'Signing in…' : 'Sign In →'}
              </button>
              <div className="form-sw">Don't have an account? <a onClick={() => { setError(''); onSwitch('register'); }}>Join free</a></div>
            </>
          ) : (
            <>
              <h2>Create account</h2>
              <p className="sub">Join thousands of artists and collectors</p>
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.5px', color: 'var(--muted)', marginBottom: 9 }}>I want to join as…</div>
                <div className="role-grid">
                  <div className={`role-opt ${role === 'buyer' ? 'on' : ''}`} onClick={() => setRole('buyer')}>
                    <h4>🛍 Buyer</h4><p>Discover &amp; collect</p>
                  </div>
                  <div className={`role-opt ${role === 'artist' ? 'on' : ''}`} onClick={() => setRole('artist')}>
                    <h4>🎨 Artist</h4><p>Sell your artwork</p>
                  </div>
                </div>
              </div>
              <div className="fg-m">
                <label>Full Name</label>
                <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Your name" />
              </div>
              <div className="fg-m">
                <label>Email Address</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" />
              </div>
              <div className="fg-m">
                <label>Password</label>
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Min 6 characters" />
              </div>
              {error && <div style={{ color: 'var(--r1)', fontSize: 12, marginBottom: 12 }}>{error}</div>}
              <button className="sub-btn" onClick={handleRegister} disabled={loading}>
                {loading ? 'Creating…' : 'Create Account →'}
              </button>
              <div className="form-sw">Already have an account? <a onClick={() => { setError(''); onSwitch('login'); }}>Sign in</a></div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
