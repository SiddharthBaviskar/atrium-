import React from 'react';
import { Link } from 'react-router-dom';

export const HeroSection = () => {
  return (
    <section className="hero">
      <div className="hero-orb hero-orb1"></div>
      <div className="hero-orb hero-orb2"></div>
      <div className="hero-orb hero-orb3"></div>
      <div className="hero-grid"></div>
      <div className="hero-content">
        <div className="hero-badge">✦ World's Premium Art Marketplace</div>
        <h1>Where Art Finds<br />Its <span className="rb-text">True Collector</span></h1>
        <p>Discover, collect, and celebrate extraordinary art from independent artists worldwide. Every piece tells a story worth owning.</p>
        <div className="hero-btns">
          <Link to="/shop" className="btn-rb">Explore Art ✦</Link>
          <button className="btn-glass" onClick={() => {}}>Sell Your Work</button>
        </div>
      </div>
    </section>
  );
};
