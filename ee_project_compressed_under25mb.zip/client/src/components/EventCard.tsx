import React from 'react';
import type { Event } from '../types';
import { useStore } from '../store/useStore';

const fmtDate = (d: string) => new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
const fmtInr = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

const TYPE_CLASSES: Record<string, string> = { workshop: 'at-ws', exhibition: 'at-ex', online: 'at-ol', sale: 'at-sale' };
const TYPE_LABELS: Record<string, string> = { workshop: '🛠 Workshop', exhibition: '🖼 Exhibition', online: '💻 Online', sale: '🏷 Sale' };

interface EventCardProps {
  event: Event;
  onRegister?: (ev: Event) => void;
}

export const EventCard: React.FC<EventCardProps> = ({ event, onRegister }) => {
  const { currentUser, events } = useStore();
  const liveEvent = events.find(e => e.id === event.id) || event;
  const regs = liveEvent.regs || [];
  const isRegistered = currentUser ? regs.some(r => r.userId === currentUser.id) : false;
  const isFull = liveEvent.seats > 0 && regs.length >= liveEvent.seats;

  const artist = useStore.getState().users.find(u => u.id === event.artistId);

  return (
    <div className="ann-card">
      <div className={`ann-type ${TYPE_CLASSES[event.type] || 'at-ws'}`}>
        {TYPE_LABELS[event.type] || event.type}
      </div>
      <div className="ann-title">{event.title}</div>
      <div className="ann-by">by {artist?.name || 'Atrium'}</div>
      <div className="ann-meta">
        <div className="ann-mi">📅 {fmtDate(event.date)}</div>
        {event.loc && <div className="ann-mi">📍 {event.loc}</div>}
        {liveEvent.seats > 0 && (
          <div className="ann-mi">🎟 {regs.length}/{liveEvent.seats} registered</div>
        )}
      </div>
      {event.description && (
        <div style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 14, lineHeight: 1.6 }}>{event.description}</div>
      )}
      <div className="ann-foot">
        <div className="ann-price">{event.fee > 0 ? fmtInr(event.fee) : 'Free'}</div>
        {isRegistered ? (
          <button className="reg-btn registered">✓ Registered</button>
        ) : isFull ? (
          <button className="reg-btn full">Sold Out</button>
        ) : (
          <button className="reg-btn" onClick={() => onRegister?.(event)}>
            {event.fee > 0 ? 'Register →' : 'Join Free →'}
          </button>
        )}
      </div>
    </div>
  );
};
