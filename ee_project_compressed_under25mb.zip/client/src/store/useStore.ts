import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Artwork, Order, Event, CartItem, Messages, Post, AppNotification, Report } from '../types';

const SEED_USERS: User[] = [
  { id: 'u1', name: 'Priya Mehta', email: 'priya@art.com', password: 'priya123', role: 'artist', bio: 'Digital artist specializing in surrealist landscapes.', cat: 'Digital Art', emoji: '🎨', followers: ['u3'], joinedAt: '2024-01-15' },
  { id: 'u2', name: 'Admin', email: 'admin@atrium.com', password: 'admin123', role: 'admin', bio: 'Platform administrator.', emoji: '⚙️', followers: [], joinedAt: '2023-10-01' },
  { id: 'u3', name: 'Anjali Roy', email: 'anjali@email.com', password: 'anjali123', role: 'buyer', bio: 'Art collector and enthusiast.', emoji: '🛍️', followers: [], joinedAt: '2024-03-20' },
  { id: 'u4', name: 'Ravi Sharma', email: 'ravi@art.com', password: 'ravi123', role: 'artist', bio: 'Oil painter with a classical touch.', cat: 'Oil Painting', emoji: '🖌️', followers: ['u3'], joinedAt: '2024-02-10' },
  { id: 'u5', name: 'Leila Nakamura', email: 'leila@art.com', password: 'leila123', role: 'artist', bio: 'Abstract sculptor and mixed media artist.', cat: 'Sculpture', emoji: '🗿', followers: [], joinedAt: '2024-04-05' },
];

const SEED_ARTWORKS: Artwork[] = [
  { id: 'a1', title: 'Neon Dreams', description: 'A surrealist digital painting exploring cyberpunk aesthetics.', price: 12500, cat: 'Digital Art', artistId: 'u1', emoji: '🌌', featured: true, createdAt: '2024-04-01', likes: ['u3'], status: 'approved' },
  { id: 'a2', title: 'Golden Harvest', description: 'Oil on canvas depicting autumn fields at golden hour.', price: 45000, cat: 'Oil Painting', artistId: 'u4', emoji: '🌾', featured: true, createdAt: '2024-03-15', likes: [], status: 'approved' },
  { id: 'a3', title: 'Urban Pulse', description: 'Mixed media street art inspired by Mumbai\'s energy.', price: 8900, cat: 'Mixed Media', artistId: 'u1', emoji: '🏙️', createdAt: '2024-04-10', likes: ['u3'], status: 'approved' },
  { id: 'a4', title: 'Serene Waters', description: 'Watercolor landscape of the Kashmir valley.', price: 6500, cat: 'Watercolor', artistId: 'u4', emoji: '🏔️', createdAt: '2024-02-28', likes: [], status: 'approved' },
  { id: 'a5', title: 'Void & Form', description: 'Abstract sculpture exploring negative space.', price: 95000, cat: 'Sculpture', artistId: 'u5', emoji: '🗿', featured: true, createdAt: '2024-04-20', likes: [], status: 'approved' },
  { id: 'a6', title: 'Circuit Garden', description: 'AI-assisted generative art blending tech and nature.', price: 3200, cat: 'AI Art', artistId: 'u1', emoji: '🌿', createdAt: '2024-05-01', likes: [], status: 'approved' },
  { id: 'a7', title: 'Rajput Heritage', description: 'Traditional miniature painting in Rajasthani style.', price: 22000, cat: 'Traditional', artistId: 'u4', emoji: '🏛️', createdAt: '2024-01-20', likes: [], status: 'approved' },
  { id: 'a8', title: 'Fractured Light', description: 'Abstract digital composition exploring chromatic dispersion.', price: 7800, cat: 'Digital Art', artistId: 'u1', emoji: '💎', createdAt: '2024-05-05', likes: [], status: 'approved' },
];

const SEED_EVENTS: Event[] = [
  { id: 'e1', title: 'Digital Art Masterclass', type: 'workshop', artistId: 'u1', date: '2025-07-15', loc: 'Mumbai Art Hub', fee: 1200, seats: 30, description: 'Learn advanced digital painting techniques.', regs: [], status: 'active' },
  { id: 'e2', title: 'Classical Portraits Exhibition', type: 'exhibition', artistId: 'u4', date: '2025-08-01', loc: 'Delhi Gallery', fee: 0, seats: 0, description: 'A month-long exhibition of classical portrait art.', regs: [], status: 'active' },
  { id: 'e3', title: 'NFT & Web3 Art Seminar', type: 'online', artistId: 'u1', date: '2025-07-20', loc: 'Online via Zoom', fee: 500, seats: 100, description: 'Understanding the future of digital ownership.', regs: [], status: 'active' },
  { id: 'e4', title: 'Summer Art Sale', type: 'sale', artistId: 'u2', date: '2025-07-01', loc: 'Atrium Platform', fee: 0, seats: 0, description: 'Up to 30% off on selected artworks.', regs: [], status: 'active' },
];

const SEED_POSTS: Post[] = [
  { id: 'p1', artistId: 'u1', title: 'My first NFT sold for ₹50,000!', text: 'Absolutely thrilled to share that my piece "Neon Dreams" just sold on the blockchain for a record amount. Thank you to all my supporters! 🎉', tag: 'achievement', likes: 42, shares: 15, createdAt: '2024-05-02' },
  { id: 'p2', artistId: 'u4', title: 'New series: "Timeless India" in progress', text: 'Currently working on a 10-piece oil series exploring historic Indian architecture. Here\'s a peek at piece #3.', tag: 'post', likes: 28, shares: 8, createdAt: '2024-05-01' },
];

type Theme = 'dark' | 'light';

interface AppState {
  // Auth
  currentUser: User | null;
  login: (email: string, password: string) => { success: boolean; message: string };
  register: (name: string, email: string, password: string, role: 'buyer' | 'artist') => { success: boolean; message: string };
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;

  // Theme
  theme: Theme;
  toggleTheme: () => void;

  // Data
  users: User[];
  artworks: Artwork[];
  orders: Order[];
  events: Event[];
  posts: Post[];
  cart: CartItem[];
  wishlist: string[];
  messages: Messages;
  notifications: AppNotification[];
  reports: Report[];

  // Actions
  addArtwork: (art: Omit<Artwork, 'id' | 'createdAt' | 'likes' | 'status'>) => void;
  updateArtwork: (id: string, data: Partial<Artwork>) => void;
  removeArtwork: (id: string) => void;
  addToCart: (artId: string) => boolean;
  removeFromCart: (artId: string) => void;
  checkout: () => number;
  toggleWishlist: (artId: string) => void;
  registerEvent: (eventId: string) => { success: boolean; ticketId?: string; seat?: string };
  sendMessage: (toId: string, text: string) => void;
  markConvRead: (convId: string) => void;
  addNotification: (notif: Omit<AppNotification, 'id' | 'at' | 'read'>) => void;
  markNotifRead: (notifId: string) => void;
  clearNotifications: () => void;

  // Admin actions
  banUser: (userId: string) => void;
  unbanUser: (userId: string) => void;
  deleteUser: (userId: string) => void;
  warnUser: (userId: string, message: string) => void;
  approveArtwork: (artId: string) => void;
  rejectArtwork: (artId: string, reason: string) => void;
  addReport: (report: Omit<Report, 'id' | 'status' | 'createdAt'>) => void;
  updateReportStatus: (reportId: string, status: Report['status']) => void;
  removeEvent: (eventId: string) => void;
  addEvent: (event: Omit<Event, 'id' | 'regs'>) => void;
  addPost: (post: Omit<Post, 'id' | 'createdAt' | 'likes' | 'shares'>) => void;
  likePost: (postId: string) => void;
  followArtist: (artistId: string) => void;
}

const uid = () => Math.random().toString(36).slice(2, 10);
const makeConvId = (a: string, b: string) => [a, b].sort().join('__');

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      theme: 'dark',
      users: SEED_USERS,
      artworks: SEED_ARTWORKS,
      orders: [],
      events: SEED_EVENTS,
      posts: SEED_POSTS,
      cart: [],
      wishlist: [],
      messages: {},
      notifications: [],
      reports: [],

      login: (email, password) => {
        const user = get().users.find(u => u.email === email && u.password === password);
        if (!user) return { success: false, message: 'Invalid email or password.' };
        if (user.banned) return { success: false, message: 'Your account has been suspended.' };
        set({ currentUser: user });
        document.documentElement.setAttribute('data-theme', get().theme);
        return { success: true, message: `Welcome back, ${user.name}!` };
      },

      register: (name, email, password, role) => {
        const exists = get().users.find(u => u.email === email);
        if (exists) return { success: false, message: 'Email already in use.' };
        const newUser: User = { id: uid(), name, email, password, role, followers: [], joinedAt: new Date().toISOString() };
        set(s => ({ users: [...s.users, newUser], currentUser: newUser }));
        return { success: true, message: `Welcome to Atrium, ${name}!` };
      },

      logout: () => set({ currentUser: null, cart: [], wishlist: [] }),

      updateProfile: (data) => {
        const cu = get().currentUser;
        if (!cu) return;
        const updated = { ...cu, ...data };
        set(s => ({
          currentUser: updated,
          users: s.users.map(u => u.id === cu.id ? updated : u),
        }));
      },

      toggleTheme: () => {
        const next = get().theme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        set({ theme: next });
      },

      addArtwork: (art) => {
        const newArt: Artwork = { ...art, id: uid(), createdAt: new Date().toISOString(), likes: [], status: 'pending' };
        set(s => ({ artworks: [...s.artworks, newArt] }));
      },

      updateArtwork: (id, data) => {
        set(s => ({ artworks: s.artworks.map(a => a.id === id ? { ...a, ...data } : a) }));
      },

      removeArtwork: (id) => {
        set(s => ({ artworks: s.artworks.filter(a => a.id !== id) }));
      },

      addToCart: (artId) => {
        const { cart, artworks, currentUser, users } = get();
        if (!currentUser) return false;
        if (cart.find(i => i.artId === artId)) return false;
        const art = artworks.find(a => a.id === artId);
        if (!art || art.sold || art.status !== 'approved') return false;
        const artist = users.find(u => u.id === art.artistId);
        if (!artist || artist.banned) return false;

        set(s => ({ cart: [...s.cart, { artId, at: new Date().toISOString() }] }));
        return true;
      },

      removeFromCart: (artId) => {
        set(s => ({ cart: s.cart.filter(i => i.artId !== artId) }));
      },

      checkout: () => {
        const { cart, artworks, orders, currentUser, addNotification } = get();
        if (!currentUser || !cart.length) return 0;
        let placed = 0;
        const newOrders: Order[] = [];
        const updatedArts = artworks.map(a => {
          const inCart = cart.find(i => i.artId === a.id);
          if (inCart && !a.sold) {
            newOrders.push({ id: '#AT' + uid().slice(0, 4).toUpperCase(), artId: a.id, buyerId: currentUser.id, amount: a.price, date: new Date().toISOString(), status: 'Paid' });
            placed++;
            // Notify artist
            addNotification({
              userId: a.artistId,
              title: 'New Sale! 💰',
              message: `Your artwork "${a.title}" was just purchased by ${currentUser.name}.`,
              type: 'sale',
              link: '/artist-dashboard'
            });
            return { ...a, sold: true };
          }
          return a;
        });
        set({ artworks: updatedArts, orders: [...orders, ...newOrders], cart: [] });
        return placed;
      },

      toggleWishlist: (artId) => {
        const wl = get().wishlist;
        set({ wishlist: wl.includes(artId) ? wl.filter(i => i !== artId) : [...wl, artId] });
      },

      registerEvent: (eventId) => {
        const cu = get().currentUser;
        if (!cu) return { success: false };
        const events = get().events;
        const ev = events.find(e => e.id === eventId);
        if (!ev) return { success: false };
        const regs = ev.regs || [];
        if (regs.find(r => r.userId === cu.id)) return { success: false };
        if (ev.seats > 0 && regs.length >= ev.seats) return { success: false };
        const ticketId = 'ATR-' + uid().toUpperCase().slice(0, 8);
        const seatLetters = 'ABCDEFGH';
        const seat = seatLetters[Math.floor(Math.random() * seatLetters.length)] + (Math.floor(Math.random() * 30) + 1);
        const newReg = { userId: cu.id, userName: cu.name, ticketId, seat, at: new Date().toISOString() };
        set(s => ({ events: s.events.map(e => e.id === eventId ? { ...e, regs: [...(e.regs || []), newReg] } : e) }));
        return { success: true, ticketId, seat };
      },

      sendMessage: (toId, text) => {
        const cu = get().currentUser;
        if (!cu || !text.trim()) return;
        const cid = makeConvId(cu.id, toId);
        const msg = { id: uid(), fromId: cu.id, text, at: new Date().toISOString(), read: false };
        set(s => ({ messages: { ...s.messages, [cid]: [...(s.messages[cid] || []), msg] } }));
        
        // Notify recipient
        get().addNotification({
          userId: toId,
          title: 'New Message 💬',
          message: `${cu.name} sent you a message: "${text.slice(0, 30)}..."`,
          type: 'message',
          link: '/messages'
        });

        // Auto-reply
        setTimeout(() => {
          const replies = ['Thank you for your message! 🎨', 'Hi! Happy to help.', 'Appreciate your interest in my work!', 'Feel free to ask about the artwork.', 'Lovely to hear from you! 😊'];
          const replyText = replies[Math.floor(Math.random() * replies.length)];
          const reply = { id: uid(), fromId: toId, text: replyText, at: new Date().toISOString(), read: false };
          set(s => ({ messages: { ...s.messages, [cid]: [...(s.messages[cid] || []), reply] } }));
          
          // Notify sender of reply
          get().addNotification({
            userId: cu.id,
            title: 'New Reply 💬',
            message: `You received a reply to your message.`,
            type: 'message',
            link: '/messages'
          });
        }, 1500);
      },

      markConvRead: (convId) => {
        const cu = get().currentUser;
        if (!cu) return;
        const msgs = get().messages;
        const updated = (msgs[convId] || []).map(m => m.fromId !== cu.id ? { ...m, read: true } : m);
        set(s => ({ messages: { ...s.messages, [convId]: updated } }));
      },

      addNotification: (notif) => {
        const newNotif: AppNotification = { ...notif, id: uid(), at: new Date().toISOString(), read: false };
        set(s => ({ notifications: [newNotif, ...s.notifications] }));
      },

      markNotifRead: (notifId) => {
        set(s => ({ notifications: s.notifications.map(n => n.id === notifId ? { ...n, read: true } : n) }));
      },

      clearNotifications: () => {
        const cu = get().currentUser;
        if (!cu) return;
        set(s => ({ notifications: s.notifications.filter(n => n.userId !== cu.id) }));
      },

      // Admin
      banUser: (userId) => {
        set(s => ({ users: s.users.map(u => u.id === userId ? { ...u, banned: true } : u) }));
      },
      unbanUser: (userId) => {
        set(s => ({ users: s.users.map(u => u.id === userId ? { ...u, banned: false } : u) }));
      },
      deleteUser: (userId) => {
        set(s => ({
          users: (s.users || []).filter(u => u.id !== userId),
          artworks: (s.artworks || []).filter(a => a.artistId !== userId),
          events: (s.events || []).filter(e => e.artistId !== userId),
          posts: (s.posts || []).filter(p => p.artistId !== userId),
        }));
      },
      warnUser: (userId, message) => {
        get().addNotification({
          userId,
          title: 'Admin Warning ⚠️',
          message: message,
          type: 'warning'
        });
      },
      approveArtwork: (artId) => {
        set(s => ({ artworks: s.artworks.map(a => a.id === artId ? { ...a, status: 'approved' } : a) }));
        const art = get().artworks.find(a => a.id === artId);
        if (art) {
          get().addNotification({
            userId: art.artistId,
            title: 'Artwork Approved ✅',
            message: `Your artwork "${art.title}" has been approved and is now public.`,
            type: 'info'
          });
        }
      },
      rejectArtwork: (artId, reason) => {
        set(s => ({ artworks: s.artworks.map(a => a.id === artId ? { ...a, status: 'rejected' } : a) }));
        const art = get().artworks.find(a => a.id === artId);
        if (art) {
          get().addNotification({
            userId: art.artistId,
            title: 'Artwork Rejected ❌',
            message: `Your artwork "${art.title}" was rejected. Reason: ${reason}`,
            type: 'warning'
          });
        }
      },
      addReport: (report) => {
        const newReport: Report = { ...report, id: uid(), status: 'pending', createdAt: new Date().toISOString() };
        set(s => ({ reports: [...s.reports, newReport] }));
        
        // Notify admin
        const admin = get().users.find(u => u.role === 'admin');
        if (admin) {
           get().addNotification({
            userId: admin.id,
            title: 'New Report 🚨',
            message: `A new report has been filed against an ${report.targetType}.`,
            type: 'warning',
            link: '/admin'
          });
        }
      },
      updateReportStatus: (reportId, status) => {
        set(s => ({ reports: s.reports.map(r => r.id === reportId ? { ...r, status } : r) }));
      },
      removeEvent: (eventId) => {
        set(s => ({ events: s.events.filter(e => e.id !== eventId) }));
      },
      addEvent: (event) => {
        const newEv: Event = { ...event, id: uid(), regs: [] };
        set(s => ({ events: [...s.events, newEv] }));
      },
      addPost: (post) => {
        const newPost: Post = { ...post, id: uid(), createdAt: new Date().toISOString(), likes: 0, shares: 0 };
        set(s => ({ posts: [...s.posts, newPost] }));
      },
      likePost: (postId) => {
        set(s => ({ posts: s.posts.map(p => p.id === postId ? { ...p, likes: p.likes + 1 } : p) }));
      },
      followArtist: (artistId) => {
        const cu = get().currentUser;
        if (!cu) return;
        const artist = get().users.find(u => u.id === artistId);
        if (!artist) return;
        const followers = artist.followers || [];
        const isFollowing = followers.includes(cu.id);
        const newFollowers = isFollowing ? followers.filter(f => f !== cu.id) : [...followers, cu.id];
        
        if (!isFollowing) {
          get().addNotification({
            userId: artistId,
            title: 'New Follower! 👤',
            message: `${cu.name} started following you.`,
            type: 'follower',
            link: `/artists/${artistId}`
          });
        }

        set(s => ({
          users: s.users.map(u => u.id === artistId ? { ...u, followers: newFollowers } : u),
        }));
      },
    }),
    {
      name: 'atrium-store',
      partialize: (state) => ({
        currentUser: state.currentUser,
        theme: state.theme,
        users: state.users,
        artworks: state.artworks,
        orders: state.orders,
        events: state.events,
        posts: state.posts,
        cart: state.cart,
        wishlist: state.wishlist,
        messages: state.messages,
        notifications: state.notifications,
        reports: state.reports,
      }),
    }
  )
);

export const makeConvId2 = makeConvId;
